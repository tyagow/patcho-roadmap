#!/usr/bin/env python3
# Gera os SVGs do logo Patcho com a fonte Barlow Condensed embutida (base64).
import base64, os, pathlib, re

ROOT = pathlib.Path(__file__).parent
SVG = ROOT/"svg"; HTML = ROOT/"_print"; SVG.mkdir(exist_ok=True); HTML.mkdir(exist_ok=True)

def b64(p): return base64.b64encode((ROOT/"fonts"/p).read_bytes()).decode()
XB = b64("BarlowCondensed-ExtraBold.ttf")
SB = b64("BarlowCondensed-SemiBold.ttf")

FONTCSS = f"""@font-face{{font-family:'BarlowCondensed';font-weight:800;font-style:normal;src:url(data:font/ttf;base64,{XB}) format('truetype');}}
@font-face{{font-family:'BarlowCondensed';font-weight:600;font-style:normal;src:url(data:font/ttf;base64,{SB}) format('truetype');}}"""

IP = "M 170.2 210 C 181.3 205.3 195.2 204.6 211.8 192.4 C 228.4 180.2 226.8 171.8 232.3 164.3 L 243.8 164.2 L 244.9 210 Z"
IXW = 74.7
def iconG(left, baseY, s, fill):
    return f'<g transform="translate({left:.2f} {baseY}) scale({s}) translate(-170.2 -210)"><path d="{IP}" fill="{fill}"/></g>'
def gline(x1,x2,y,col,w):
    return f'<line x1="{x1}" y1="{y}" x2="{x2}" y2="{y}" stroke="{col}" stroke-width="{w}" stroke-linecap="round"/>'

CW = {
 "":        ("#3B2F25","#B98B5E","#3B2F25","#6B7150"),
 "-black":  ("#171109","#171109","#171109","#171109"),
 "-white":  ("#ECE5D6","#ECE5D6","#ECE5D6","#ECE5D6"),
}

def wrap(vb, w, h, inner):
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" width="{w}" height="{h}">\n'
            f'<style>{FONTCSS}</style>\n{inner}\n</svg>\n')

def text(x,y,fs,fill,ls,weight,s):
    return f'<text x="{x}" y="{y}" font-family="BarlowCondensed" font-weight="{weight}" font-size="{fs}" fill="{fill}" text-anchor="middle" letter-spacing="{ls}">{s}</text>'

assets = {}

# STACKED
for suf,(ic,gc,wc,tc) in CW.items():
    s=1.8; baseY=128; left=160-(IXW*s)/2
    inner = (iconG(left,baseY,s,ic) + gline(round(left),round(left+IXW*s),baseY,gc,3.5)
             + text(160,196,60,wc,7,800,"PATCHO")
             + text(160,218,11,tc,6,600,"BACKYARD DIRT JUMP CO."))
    assets[f"patcho-stacked{suf}"] = wrap("0 0 320 250",640,500,inner)

# ICON
for suf,(ic,gc,wc,tc) in CW.items():
    s=1.7; baseY=110; left=100-(IXW*s)/2
    inner = iconG(left,baseY,s,ic) + gline(round(left),round(left+IXW*s),baseY,gc,3)
    assets[f"patcho-icon{suf}"] = wrap("0 0 200 130",400,260,inner)

# HORIZONTAL
ic,gc,wc,tc = CW[""]
s=1.5; baseY=108; left=90-(IXW*s)/2
inner = (iconG(left,baseY,s,ic) + gline(round(left),round(left+IXW*s),baseY,gc,3)
         + f'<line x1="172" y1="46" x2="172" y2="120" stroke="#7A6A52" stroke-width="1.5"/>'
         + f'<text x="190" y="96" font-family="BarlowCondensed" font-weight="800" font-size="52" fill="{wc}" letter-spacing="5">PATCHO</text>'
         + f'<text x="192" y="116" font-family="BarlowCondensed" font-weight="600" font-size="10" fill="{tc}" letter-spacing="5">BUILT ON DIRT</text>')
assets["patcho-horizontal"] = wrap("0 0 440 150",880,300,inner)

# SELO (patch) — icone com centralização ÓPTICA (config C: left=56, baseY=103)
sl = ('<defs><path id="fpt" d="M48 90 A42 42 0 0 1 132 90"/><path id="fpb" d="M37 90 A53 53 0 0 0 143 90"/></defs>'
      '<circle cx="90" cy="90" r="74" fill="#B98B5E" stroke="#8a6440" stroke-width="3"/>'
      '<circle cx="90" cy="90" r="62" fill="#ECE5D6"/>'
      '<circle cx="90" cy="90" r="62" fill="none" stroke="#3B2F25" stroke-width="2" stroke-dasharray="1.5 5"/>'
      + gline(55,105,103,"#6B7150",2.5)
      + iconG(56,103,0.66,"#3B2F25")
      + '<text font-family="BarlowCondensed" font-weight="800" font-size="16" fill="#3B2F25" letter-spacing="3"><textPath href="#fpt" startOffset="50%" text-anchor="middle">PATCHO</textPath></text>'
      + '<text font-family="BarlowCondensed" font-weight="600" font-size="9" fill="#6B7150" letter-spacing="2"><textPath href="#fpb" startOffset="50%" text-anchor="middle">LOAM PREMIUM</textPath></text>')
assets["patcho-selo"] = wrap("0 0 180 180",540,540,sl)

for name, svg in assets.items():
    (SVG/f"{name}.svg").write_text(svg)
    m = re.search(r'width="(\d+)" height="(\d+)"', svg)
    w,h = m.group(1), m.group(2)
    body = svg.split("?>\n",1)[1]
    html = (f'<!DOCTYPE html><html><head><meta charset="utf-8"><style>'
            f'@page{{size:{w}px {h}px;margin:0}}html,body{{margin:0;padding:0}}'
            f'svg{{display:block}}</style></head><body>{body}</body></html>')
    (HTML/f"{name}.html").write_text(html)

print("SVGs:", len(assets))
