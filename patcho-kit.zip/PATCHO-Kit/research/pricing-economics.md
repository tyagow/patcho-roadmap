# Patcho — Preço & Unit Economics

> Pesquisa interna · mid-2026 · todos os valores em **BRL (R$)**, USD secundário
> Foco: micro-marca de streetwear premium *bootstrapped*, base Ibiraquera/Imbituba-SC, modelo de *drops* + patches + conteúdo.
> Posicionamento "Loam Premium": preço alto justificado por restrição, qualidade e pertencimento à *parche*.

---

## TL;DR — Tabela de preços recomendados

| Produto | Preço de venda (R$) | COGS aprox. (R$) | Margem bruta % | Comentário |
|---|---|---|---|---|
| **Patch bordado** (8–9 cm) | **R$ 39–49** | ~R$ 12–16 | ~65–70% | Produto-âncora / "selo de membro". Margem alta, vira ferramenta de comunidade. |
| **Kit de stickers** (cartela 4–6 un) | **R$ 19–29** | ~R$ 4–7 | ~70–78% | Add-on de carrinho, custo de aquisição de fã. Quase margem de patch. |
| **Camiseta heavyweight** (estampada) | **R$ 119–149** | ~R$ 38–52 | ~60–68% | Coração do drop. Premium acima do "nacional médio" (R$ 90–110), abaixo de Carnan/Piet (R$ 180+). |
| **Boné** (trucker/aba curva, bordado) | **R$ 89–119** | ~R$ 30–42 | ~60–66% | Margem boa, baixo risco de grade (one-size). |
| **Moletom** (hoodie heavyweight) | **R$ 269–329** | ~R$ 95–130 | ~60–64% | Item de inverno / topo de funil de receita. Alto capital travado — só após validar tee. |

> Regra de ouro do *bootstrap*: **preço de venda ≈ 2,5× a 3,5× COGS** para sobreviver a frete subsidiado, impostos, taxa de gateway e devoluções. Patcho deve mirar a faixa **3×+** por causa do posicionamento premium.

---

## 1. Benchmark de mercado — o que marcas BR comparáveis cobram (2026)

Levantamento de marcas independentes brasileiras de streetwear:

| Marca / faixa | Camiseta | Moletom/Hoodie | Boné | Posição |
|---|---|---|---|---|
| Bilix / básico premium | R$ 49–69 | — | — | Entrada, alto volume |
| **Hardvision** (RJ, heavyweight) | **R$ 109,90** | — | **R$ 89,90** | Comparável direto a Patcho |
| The Dust Company / Overcome | R$ 99–139 | R$ 220–320 | R$ 90–120 | Mid premium nacional |
| FAS Clothing (premium) | R$ 140–200 | R$ 218–668 | — | Premium alto |
| Carnan / Piet (top nacional) | R$ 180–280 | R$ 400–700 | R$ 150+ | Topo — hype/design |

**Leitura para Patcho:** a faixa "premium independente legível" para camiseta heavyweight é **R$ 100–150**. Hardvision (heavyweight carioca, comparável de proposta) ancora em **R$ 109,90** com Pix a ~R$ 99 e boné a R$ 89,90. Patcho, com identidade mais refinada + narrativa de nicho (dirt jump / loam), pode posicionar **acima de Hardvision mas abaixo de Carnan**: tee **R$ 119–149**, boné **R$ 89–119**. O nicho dirt-jump tem disposição a pagar por pertencimento — não competir em preço com básico de marketplace.

---

## 2. COGS por produto — small batch (BR, 2026)

### 2.1 Patch bordado
Fornecedores: **Eagle Patches**, **Patch Bordado**, **Toca dos Bordados**, **Linha Darte**.
Programação (digitalização do bordado) costuma ser **grátis** no primeiro pedido.

| Tamanho | 25 un | 50 un | 100 un |
|---|---|---|---|
| 7 cm | R$ 14,70 | R$ 13,05 | R$ 10,75 |
| 8 cm | R$ 15,70 | R$ 14,05 | R$ 11,75 |
| 9 cm | R$ 16,70 | R$ 15,05 | R$ 12,75 |

**COGS recomendado:** patch 8–9 cm, lote de 50 → **~R$ 14–15/un**; lote de 100 → **~R$ 12/un**.
Venda a R$ 39–49 → margem bruta **65–70%**. Mínimo viável: 10–25 un (custo unitário sobe para ~R$ 16–17).

### 2.2 Kit de stickers
Fornecedor de referência: **Rei do Sticker** (vinil eco-solvente, laminado, à prova d'água, recorte).
- 25 cartelas (10×15 / 21×15 cm) ≈ R$ 98–140 → **~R$ 4–6/cartela**.
- 500 rótulos vinil ≈ R$ 79–212 → **~R$ 0,16–0,42/un** (para stickers soltos / brinde de carrinho).

**COGS recomendado:** cartela com 4–6 stickers → **~R$ 4–7/un**. Venda a R$ 19–29 → margem **70–78%**. Stickers soltos viram **brinde grátis em todo pedido** (custo de aquisição < R$ 1), reforçando a *parche*.

### 2.3 Camiseta heavyweight (estampada)
COGS = **blank + estampa**.

**Blank (malha pesada, fio 30.1 penteado, ~170–185 g/m²):**
- Atacado nacional (El Elyon, Almeida Bueno, Empório da Família): **~R$ 23–35/un** dependendo de gramatura/cor/volume. Heavyweight "de verdade" (200 g/m²+) fica na ponta alta: **~R$ 30–40**.
- Kits de revenda básicos chegam a ~R$ 23/un, mas são leves demais para a proposta "premium".

**Estampa:**
- **DTF** (Direct-to-Film): mínimo 1 peça, **~R$ 10–18/estampa A3**; insumo bruto R$ 5–10. Ideal para *small batch*.
- **Serigrafia**: só compensa a partir de ~30–50 peças/cor; abaixo disso o set-up mata o unitário.

**COGS recomendado (lote ~30–50 tees):**
| Cenário | Blank | Estampa | Embalagem/etiqueta | COGS total |
|---|---|---|---|---|
| Lean (DTF, blank médio) | R$ 28 | R$ 12 | R$ 3 | **~R$ 43** |
| Premium (heavyweight 200g + serigrafia 50un) | R$ 36 | R$ 10 | R$ 6 | **~R$ 52** |
| Piso possível (blank ~R$23 + DTF R$10) | R$ 23 | R$ 10 | R$ 3 | **~R$ 36–38** |

Venda a R$ 119–149 → margem bruta **60–68%** (antes de taxa/imposto/frete).

### 2.4 Boné
- Boné trucker/aba curva em branco para bordado: **~R$ 18–30/un** atacado.
- Bordado/aplicação: **~R$ 8–15/un** (in-house ou terceirizado, lote pequeno).
- **COGS:** ~R$ 30–42. Venda R$ 89–119 → margem **60–66%**. Vantagem: *one-size*, zero risco de grade (P/M/G/GG).

### 2.5 Moletom (hoodie heavyweight)
- Blank moletom flanelado/peletizado premium: **~R$ 70–110/un** atacado pequeno.
- Estampa (DTF grande / serigrafia): **~R$ 15–25**.
- **COGS:** ~R$ 95–130. Venda R$ 269–329 → margem **60–64%**.
- ⚠️ Maior capital travado por unidade + risco de grade. **Não entra no 1º drop** — só após a camiseta validar demanda.

---

## 3. Da margem bruta à margem líquida — os "vazamentos"

Em cada venda online entram custos que comem a margem bruta:

| Custo | Faixa BR 2026 | Observação |
|---|---|---|
| **Plataforma** (Nuvemshop plano Começo / Loja Integrada grátis) | **0%** | Nenhuma cobra comissão por venda no plano base. |
| **Gateway / Pix** | **~1%** (Pix via Nuvem Pago / Pagali) | Cartão crédito ~3,5–4,5% + parcelamento; **incentivar Pix** com 5% off ainda sai barato. |
| **Imposto (Simples Nacional, Anexo I comércio)** | **4% efetivo** (1ª faixa, até R$ 180k/ano) | Se MEI (limite R$ 169.440/ano): DAS fixo ~R$ 76/mês, sem % por venda. |
| **Frete subsidiado** | **R$ 0–25/pedido** | "Frete grátis acima de R$X" é norma; PAC Mini via Melhor Envio é o mais barato para tee (~R$ 12–22 Sul/Sudeste, mais p/ Norte). |
| **Embalagem premium** | **R$ 3–8/pedido** | Parte da experiência "loam premium" (papel kraft, selo, card). |
| **Devolução/perda** | **~3–5%** provisão | |

**Exemplo — camiseta vendida a R$ 139, COGS R$ 45, pago via Pix:**
- Receita: R$ 139,00
- (−) Imposto Simples 4%: −R$ 5,56
- (−) Pix ~1%: −R$ 1,39
- (−) COGS: −R$ 45,00
- (−) Embalagem: −R$ 5,00
- (−) Frete subsidiado (parcial): −R$ 8,00
- **= Lucro líquido ≈ R$ 74 → margem líquida ~53%**

Mesmo com frete subsidiado e impostos, a camiseta premium entrega **R$ 70+ de lucro líquido por unidade** — saudável para *bootstrap*. Patch a R$ 44 (COGS R$ 14) rende **~R$ 26 líquidos (~59%)** e ainda recruta membro da tribo.

---

## 4. O modelo de drop — capital inicial e break-even

### Drop 1 (lean): patches + stickers + 1 camiseta

Premissa de inventário inicial conservador:
- **50 patches** @ R$ 14 = R$ 700
- **25 cartelas de sticker** @ R$ 5 = R$ 125 (+ 500 stickers soltos brinde ≈ R$ 100)
- **40 camisetas** (1 arte, grade P–GG): blank R$ 30 + estampa R$ 12 = R$ 42 × 40 = **R$ 1.680**
- **Embalagem premium** (kraft + selo + card) ~80 pedidos: R$ 5 × 80 = R$ 400
- **Setup**: domínios (registro.br ~R$ 40/ano + .com ~R$ 60/ano), Nuvemshop plano grátis R$ 0, programação bordado R$ 0
- **Fotos/conteúdo do drop**: faça-você-mesmo R$ 0–300

| Item | Capital (R$) |
|---|---|
| Patches (50) | 700 |
| Stickers (25 cartelas + brinde) | 225 |
| Camisetas (40) | 1.680 |
| Embalagem | 400 |
| Domínios + setup | 150 |
| Reserva / imprevistos (~15%) | 480 |
| **TOTAL DROP 1 (lean)** | **≈ R$ 3.635** |

**Receita potencial se vender tudo:**
- 40 tees × R$ 139 = R$ 5.560
- 50 patches × R$ 44 = R$ 2.200
- 25 kits sticker × R$ 24 = R$ 600
- **Bruto ≈ R$ 8.360** → líquido pós-custos **≈ R$ 4.500–5.000**

**Break-even (recuperar os R$ 3.635):**
- Só camisetas: **~50–52 unidades** de lucro... mas só há 40 → precisa do mix.
- Mix realista: vender **~28 camisetas + 30 patches + 12 kits** já cobre o capital do drop.
- Em unidades de margem: ~**26 camisetas equivalentes** pagam o drop inteiro.
- **Sell-through de ~65% do estoque** = break-even. Acima disso é lucro reinvestível no Drop 2.

### Cashflow do modelo de drop
1. **Pré-venda / lista de espera** (conteúdo primeiro): mede demanda antes de gastar.
2. Idealmente **abrir encomenda com Pix antecipado** em parte do lote (sob demanda DTF permite isso) → o cliente financia o estoque, capital de giro ≈ R$ 0.
3. Produzir em lote pequeno, esgotar, **reinvestir 100% do lucro no Drop 2** com SKU adicional (boné, depois moletom no inverno).
4. Nunca segurar grade morta: DTF sob demanda + bordado em lote reduzem encalhe.

---

## 5. Orçamento de lançamento recomendado

| Cenário | Investimento (R$) | O que cobre |
|---|---|---|
| **Lean / mínimo viável** | **R$ 3.500–4.500** | Drop 1 (50 patches, stickers, 40 tees), embalagem, domínios, conteúdo DIY. Loja grátis. |
| **Confortável** | **R$ 8.000–12.000** | Drop 1 + drop 2 já fundeado (bonés), embalagem premium, ensaio de fotos/vídeo pago, registro INPI da marca (~R$ 1.000 com despachante), pequena verba de tráfego/criadores (R$ 1.000–2.000), reserva de giro. |

> **Recomendação:** começar **lean (~R$ 4.000)**, validar com pré-venda/conteúdo, e só liberar a verba "confortável" quando o Drop 1 tiver sell-through ≥ 60%. O capital mais valioso no início **não é estoque — é conteúdo** (a "história sendo filmada"). Patch + sticker são quase margem pura e servem de teste barato de tribo antes de travar capital em tee/moletom.

### Notas fiscais/jurídicas
- **MEI** (limite R$ 169.440/ano, DAS ~R$ 76/mês) é a porta de entrada perfeita; CNAE de comércio varejista de vestuário (47.51-2-99) cai no **Anexo I** se virar ME.
- **Simples Nacional Anexo I**: alíquota efetiva **4%** até R$ 180k/ano — não muda em 2026.
- **INPI**: registrar a marca "Patcho" cedo (~R$ 142 GRU básica + acompanhamento) protege o nome antes do crescimento.
- **registro.br** para patcho.com.br (~R$ 40/ano); patchoco.com via registrador .com (~R$ 50–70/ano).

---

## 6. Riscos & sensibilidades de preço
- **Frete Norte/Nordeste** pode dobrar o subsídio — considerar "frete grátis só acima de R$ 199" ou repassar parcial fora do Sul/Sudeste.
- **Câmbio**: blanks premium e insumos DTF têm componente importado; alta do dólar pressiona COGS — revisar preço a cada drop.
- **Cartão parcelado** corrói margem (3,5–4,5% + taxa de parcela); **empurrar Pix** com desconto de 5% é matematicamente melhor que absorver taxa de crédito.
- **Tamanho de grade da camiseta** é o maior risco de encalhe — começar com 1–2 artes e grade enxuta (mais M/G).

---

## Sources
- Eagle Patches — tabela de preços patch bordado por tamanho/quantidade — eaglepatches.com.br
- Toca dos Bordados / Patch Bordado / Linha Darte — patches mín. 10 un — tocadosbordados.com, patchbordado.com.br
- Hardvision (heavyweight RJ) — preços camiseta R$ 109,90 / boné R$ 89,90 — hardvision.com.br
- The Dust Company, FAS Clothing, Overcome, Carnan, Piet — benchmark streetwear nacional — thedustcompany.com.br, fasclothing.com.br
- El Elyon / Almeida Bueno / Empório da Família — blanks fio 30.1 penteado atacado (~R$ 23–35) — atacadoelelyon.com.br, almeidabueno.store
- Estamparia DTF/serigrafia — custo estampa A3 ~R$ 10–18 — estampariaexpressa.com.br, zzfabric.com.br
- Rei do Sticker — cartelas e adesivos vinil — reidosticker.com.br
- Nuvemshop / Loja Integrada — planos e taxas 2026 (0% plataforma, ~1% Pix) — nuvemshop.com.br, lojaintegrada.com.br
- Mercado Pago / Pix — taxas 2026 — mercadopago.com.br
- Simples Nacional Anexo I 2026 (4% efetivo) + limites MEI R$169.440 — contabilizei.com.br, agilize.com.br
- Melhor Envio / PAC Mini — frete econômico p/ camiseta — melhorenvio.com.br
