# Patcho — Concorrência & White Space

> Pesquisa interna · jun/2026 · base: Ibiraquera/Imbituba (SC)
> Direção da marca: **Loam Premium** — earthy, refinado, "cheira a barro". Patch = membership no parche.
> Tese: não é uma marca de roupa, é uma **história filmada que vende patches**. Tribo primeiro, produto depois.

---

## 1. Resumo executivo

O campo competitivo se divide em três blocos e Patcho não compete de frente com nenhum:

1. **Apparel técnico de MTB/ciclismo** (performance) — ASW, Mauro Ribeiro, Cognative, MAAP. Vendem função, não cultura. Não é o jogo da Patcho.
2. **Lifestyle "loam/dirt" internacional** (EUA/UK) — LOAM Clothing, Curious Creatures, Treelines Northwest, Builder Design Co., The Loam Wolf, Patagonia Dirt. **Já provaram que o tema barro/loam vende como lifestyle premium** — mas nenhum é brasileiro, nenhum é tropical/mata atlântica, nenhum é casal.
3. **Streetwear brasileiro adjacente** — Baw, Blunt, Federal Art, Kace Wear (urbano, sem bike) + **DIRT DAD** (o único nacional que cruza off-road + lifestyle, mas é moto/enduro/trilha, estética "ilustrador agressivo", não dirt-jump/barro refinado).

**O white space é nítido:** a interseção *dirt-jump + barro/mata-atlântica earthy + casal (His&Hers) + autenticidade backyard-build + Brasil bilíngue* está vazia. Os gringos têm a estética loam mas não o Brasil; os brasileiros têm o off-road mas não o refinamento earthy nem o ângulo "parche". Patcho ocupa o cruzamento.

---

## 2. Concorrentes internacionais (referência de estética e modelo)

### Os que já validaram o tema "barro/loam premium"

| Marca | País | O que faz | Preço (USD) | Aprender | Evitar |
|---|---|---|---|---|---|
| **LOAM Clothing** | EUA | "natural, earthy essence of the sport" + comunidade de riders | tees ~US$35–45 | O posicionamento earthy + linguagem de comunidade ("not clothing, a community") é exatamente a tese da Patcho | Nome genérico demais (SEO ruim, "loam" é commodity de marca) |
| **Curious Creatures** | Bozeman, MT | Apparel MTB com paleta de pigmentos da terra (ocre, marrons, "dark loam of springtime") | premium (~US$40–70) | **A paleta earthy/pigmento-de-terra é o estado da arte** — confirma que a direção Loam Premium tem mercado | Estética muito "Montana high-desert" — seca, fria. Patcho é tropical/úmida |
| **Treelines Northwest** | WA, EUA | Trail-building lifestyle, screen-print à mão, doa % p/ trail days | tees ~US$28–35, hoodie ~US$50 | Modelo lean, hand-printed, **doação a trilhas como prova de autenticidade**. Foco em "build it your way" | Visual amador (logo simples), site fraco — Patcho já está acima disso |
| **Builder Design Co.** | EUA | Trail builders / slope sculptors / free riders. "Dig Crest" = "an emblem of a culture", hand-printed sob demanda | tees ~US$30, crewneck ~US$55 | **O "Dig Crest" é o paralelo direto do patch-membership da Patcho.** "Build a jump. Build a skill. Build a bond." = tom certo | — |
| **The Loam Wolf** | EUA | Mídia (reviews) + loja "Wolfpack". Tiragens limitadas só por pré-venda ("Death Before Moped") | tees ~US$30–35 | **Mídia primeiro, produto depois** — exatamente a tese Patcho. Pré-venda = zero estoque parado | — |
| **Patagonia (Dirt Roamer/Dirt Craft)** | EUA | Linha MTB do gigante outdoor, PFAS-free | técnico (US$120+) | Linguagem "dirt" legitimada pelo topo do mercado | Não é referência de modelo lean — é escala industrial |
| **Transition Bikes (apparel)** | EUA | "Loyal to the Soil", "Topo Crest Loam Gold" | tees US$35, hoodie US$55 | **Benchmark de preço-teto de lifestyle MTB premium** importado | É braço de marca de bike, não DTC puro |

**Leitura:** o ângulo "barro = identidade" está **validado e em alta** lá fora, mas é dominado por marcas frias/secas (montanha americana) e nomes genéricos. Patcho traz o que falta: **calor tropical, mata atlântica verde + barro vermelho, e um casal real.**

### O modelo de marca a copiar: **Howies (País de Gales)**
- Casal **David + Clare Hieatt**, começaram com 4 camisetas no apartamento (1995), screen-print à mão, mudaram p/ vilarejo no campo.
- Camisetas com **slogans/história** (ambientais, autorais), algodão orgânico Oeko-Tex, preço-âncora £30 (~R$200).
- Doam 1% do faturamento a projetos grassroots. Marca **purpose-driven, narrativa de lugar e valores**.
- **Por que importa p/ Patcho:** é a prova de que casal + lugar + história + restraint + preço premium = marca durável e amada. É o "norte" do modelo, não a estética.

---

## 3. Concorrentes brasileiros (o campo onde Patcho realmente joga)

### O único cruzamento próximo: **DIRT DAD**
- Marca BR de lifestyle off-road (trilha/enduro/moto). Camisetas autorais, bonés, meias, acessórios; usa lifestyle p/ puxar venda de produto técnico (capas de banco de moto é o caixa real).
- DTC via dirtdad.com.br, Instagram-cêntrico, investe em atletas/influencers. Planeja linha fitness e feminina.
- **Lacuna que deixa aberta p/ Patcho:** estética "ilustrador agressivo/moto", não barro-refinado. É **moto/enduro**, não **dirt-jump/MTB**. Não tem ângulo casal, não tem paleta earthy-mata, não é bilíngue, não tem o conceito de "parche/membership". Patcho é a versão *refinada, ciclística e tropical* desse espaço.

### Apparel técnico de bike BR (não-concorrentes diretos, mas ocupam mindshare)
- **ASW** — MTB/downhill técnico (jaquetas, bermudas, camisas reforçadas). Função, não cultura.
- **Mauro Ribeiro** — vestuário ciclismo (tecidos importados). Estrada/performance.
- **Volt Sport** — material esportivo 100% BR, genérico.

### Streetwear BR premium (benchmark de preço e acabamento, sem bike)
- **Baw Clothing** ("We make noise, not fashion"), **Blunt Brasil** (estampas exclusivas), **Federal Art** (camisetas a partir de R$39,90), **Kace Wear** (algodão alta gramatura, caimento oversized — cliente valoriza **qualidade de bordado e costura**).
- **Leitura de preço:** streetwear BR independente vai de R$40 (entrada) a R$180+ (oversized premium algodão pesado). O valor percebido vem de **gramatura, bordado 3D e acabamento de costura** — exatamente onde restraint vira preço.

---

## 4. White Space — onde Patcho ganha

```
        BARRO/LOAM EARTHY (estética refinada)
                    ↑
   gringos:         |          ← VAZIO →
   LOAM, Curious    |     ★ PATCHO ★
   Creatures,       |   (mata verde + barro
   Builder Design   |    vermelho, casal,
                    |    dirt-jump tropical,
   ─────────────────+──────────────── BRASIL
                    |
   DIRT DAD         |     streetwear BR
   (moto/enduro,    |     (Baw, Blunt —
   ilustrador)      |      urbano, sem bike)
                    ↓
            OFF-ROAD AGRESSIVO / URBANO
```

**Quatro vetores de diferenciação (todos defensáveis e combináveis):**

1. **Paleta verde-mata + barro vermelho (tropical).** O loam internacional é ocre/marrom seco de montanha americana. Patcho é **úmido, verde, mata atlântica + barro de quintal de SC**. Ninguém ocupa o "loam tropical". Esse é o ativo visual mais raro.
2. **O casal (His&Hers).** Tiago & Jaluza. Howies prova que casal-fundador é narrativa de marca premium poderosa. Nenhum concorrente de dirt-jump tem isso. A relação *é* o conteúdo.
3. **Backyard-build / "build your own trail".** Treelines ("build it your way") e Builder Design ("build a jump, build a bond") provam que autenticidade de construção vende. Patcho tem o quintal/foam pit/trilha própria como **set de filmagem real** — não é storytelling inventado.
4. **Brasil-first, globalmente legível (bilíngue PT/EN).** Os gringos são monolíngues; os brasileiros não exportam narrativa. Patcho fala as duas línguas — vende patch em Garopaba e é legível no Instagram global.

**O patch como membership ("o parche"):** Builder Design ("Dig Crest = emblem of a culture") e The Loam Wolf ("Wolfpack") já provaram que **emblema = pertencimento**. Patcho leva isso ao centro: o produto-âncora barato (patch) é o cartão de entrada na tribo; apparel premium vem depois. Modelo de pré-venda/tiragem limitada (The Loam Wolf) = **zero estoque parado**, alinhado ao bootstrap.

---

## 5. Armadilhas a evitar (traps)

1. **Localismo elitista (a armadilha do surf).** A cultura "build your own trail" + costa de SC carrega o risco do gatekeeping ("essa trilha é nossa, você não é local"). O surf provou que localismo vira exclusão tóxica e envelhece mal. **Patcho deve ser convite, não muro** — "o parche" acolhe quem cava, não quem nasceu aqui. Comunidade aberta é o oposto exato do localismo e é o diferencial moral.
2. **Sameness de marca de bike.** ASW/Mauro Ribeiro/genéricos competem por especificação técnica e desconto. Cair em "camiseta técnica respirável" é morrer na guerra de preço. **Patcho é cultura, não tecido.**
3. **Nome/estética genérica (a armadilha do "LOAM").** "Loam" como marca é commodity (vários usam). Patcho já tem nome próprio + emblema + ícone "lip" — proteger isso (INPI) e não diluir em "mais uma marca earthy".
4. **Virar marca de produto cedo demais.** DIRT DAD precisou do caixa das capas de moto; Patagonia é escala. Patcho **bootstrapped** não pode segurar estoque. Conteúdo/comunidade primeiro, tiragens pequenas sob pré-venda, patch como âncora barata.
5. **Estética "punk-zine/mascote".** Já descartado no brief, mas é o default fácil do nicho dirt. Restraint = qualidade = preço-teto. Não trair.
6. **Ilustrador-agressivo (a rota DIRT DAD).** Tentador no off-road BR. Mas é o oposto do Loam Premium e já está ocupado. Refinamento é o fosso.

---

## 6. Realidade de canal/custo no Brasil (jun/2026)

| Item | Faixa BRL | Nota |
|---|---|---|
| Nuvemshop — Plano Começo | R$ 0/mês | Grátis, produtos ilimitados; ideal p/ validar bootstrap. Sem IA/exportação |
| Nuvemshop — Plano Essencial/Impulso | ~R$ 50–150/mês | Subir quando volume justificar |
| Pix via Nuvem Pago | 0,99% por transação | Mesmo em todos os planos; recebimento na hora |
| Boleto | R$ 2,39/venda | 2 dias úteis |
| Tarifa por venda (gateway externo) | 0,7%–2% | R$0 se usar Nuvem Pago nativo |
| Saque p/ conta (não-Bradesco) | R$ 0,99/transf. | Grátis no Bradesco |
| Patch bordado (lote pequeno) | R$ 8–18/un | Custo cai muito com volume; bordado 3D = âncora de valor |
| Camiseta premium (algodão pesado, lote pequeno) | R$ 35–70 custo → R$ 120–220 venda | Margem premium vem de gramatura/bordado/costura |
| Boné bordado | R$ 25–55 custo → R$ 90–160 venda | Trucker/dad-hat + patch removível = flexível por coleção |
| Frete (Melhor Envio/Correios PAC) | R$ 15–45/envio nacional | Nuvem Envio até 50% mais barato; SC→Sul mais barato |

**Implicação estratégica:** o stack BR (Nuvemshop Começo grátis + Pix 0,99% + Melhor Envio + Simples Nacional + INPI p/ a marca + registro.br p/ domínios) permite operar **quase sem custo fixo** — perfeito p/ bootstrap. O patch a R$8–18 de custo, vendido como "membership" a R$30–50, é o produto-âncora de margem alta e baixo risco de estoque.

---

## 7. Recomendações concretas

1. **Cravar o "loam tropical".** Liderar com verde-mata + barro vermelho de SC em toda a comunicação. É o ativo que nenhum concorrente global ou nacional tem. Fotografar barro úmido, não poeira seca.
2. **Patch primeiro, apparel depois.** Patch (R$30–50) = âncora de entrada no parche, margem alta, risco zero de estoque. Camiseta/boné premium vêm por pré-venda/tiragem limitada (modelo The Loam Wolf).
3. **O casal É a marca.** Construir o conteúdo em torno de Tiago & Jaluza (His&Hers, backyard-build real). É o fosso narrativo estilo Howies que ninguém no dirt-jump tem.
4. **Comunidade aberta como antídoto ao localismo.** "O parche" acolhe quem cava. Posicionar explicitamente contra o gatekeeping do surf — é diferencial moral e de marca.
5. **Stack lean BR:** Nuvemshop Começo (R$0) + Nuvem Pago/Pix + Melhor Envio + registrar marca no INPI (proteger nome + emblema + ícone "lip") + domínios via registro.br. Não diluir a marca em estética genérica.
6. **Bilíngue desde o dia 1.** PT-BR p/ tribo local + EN p/ legibilidade global. É o que separa Patcho dos BR (não exportam) e dos gringos (monolíngues).

---

## Fontes

- Pinkbike / Cyclingnews / BikeMag / Singletracks — panorama apparel MTB lifestyle 2026
- loamclothing.com — LOAM Clothing (posicionamento earthy/comunidade)
- BikeMag "Curious Creatures" — paleta de pigmentos da terra
- treelinesnorthwest.com — modelo trail-building lean, doação a trilhas
- builderdesign.co — "Dig Crest", linguagem de crew/build
- store.theloamwolf.com — mídia-primeiro, pré-venda/tiragem limitada
- transitionbikes.com — benchmark de preço lifestyle MTB premium (US$35–55)
- cognativemtb.com — preços tees/jerseys
- showradical.com — perfil DIRT DAD (lifestyle off-road BR)
- ASW / Mauro Ribeiro / Netshoes / MX Bikes — apparel técnico bike BR
- bawclothing.com.br / bluntbrasil.com.br / federalart.com.br / kacewear.com.br — benchmark streetwear BR premium
- camisetasem12h.com.br — personalização boné/bordado 2026
- howies.co.uk + Wikipedia "Howies" + Campaign "Champions of Design" — modelo casal-fundador/purpose
- nuvemshop.com.br + litextension/ecommercenapratica — planos/taxas Nuvemshop 2026, Pix, Nuvem Pago
- theinertia.com / surfsimply.com / Wikipedia "Surf culture" / WaveHouse — crítica ao localismo (armadilha)
