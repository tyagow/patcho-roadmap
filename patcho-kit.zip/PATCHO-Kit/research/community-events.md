# PATCHO — Comunidade & Eventos

> Pesquisa interna · jun/2026 · foco: transformar audiência em tribo + o "selo/jam assinatura" da marca.
> Base: Ibiraquera / Imbituba, Santa Catarina (litoral, mata atlântica, cultura surf+bike). Valores em **BRL**.

---

## 0. Tese central

A Patcho não vende roupa — ela **filma uma história que por acaso vende patches**. O patch é o **selo de pertencimento ao "parche"** (a crew). Toda a estratégia de comunidade segue daí:

1. **Conteúdo primeiro** → mostra a cena (vídeo de jam no quintal, trail building, dia de chuva e loam).
2. **Tribo segunda** → quem aparece, ajuda a cavar, e roda junto ganha um patch (não compra — *recebe*).
3. **Produto terceiro** → o resto da audiência quer o patch porque ele significa algo.

Isso espelha exatamente como a **Thrasher** virou bíblia do skate: não foi marketing pago, foi **respeito da comunidade + um código não-escrito** que todo mundo reconhece. O SOTY (Skater of the Year, desde 1990, primeiro foi Tony Hawk) nasceu como **uma festa de fim de ano que deu um prêmio** — barato de criar, impossível de copiar depois que vira tradição. É esse o playbook.

---

## 1. Anatomia de um Jam pequeno de dirt jump no Brasil

### 1.1 O que é um "jam" (vs. campeonato)
Jam ≠ prova cronometrada. Não tem pódio rígido nem ranking. É **sessão coletiva**: pilotos rodam juntos, "best trick", "best line", clima de festa, todo mundo bate palma. Isso é ouro para a Patcho porque:
- Custo regulatório **muito menor** que evento competitivo federado (não precisa de federação/CBC, cronometragem, arbitragem).
- Pode ser enquadrado como **evento privado/encontro de amigos** se for em terreno particular e sem venda de ingresso — o que muda radicalmente a exigência de alvará/seguro (ver §4).

### 1.2 Cultura de trail building = o próprio recrutamento
No dirt jump brasileiro é **regra não-escrita: quem anda, ajuda a cavar e manter as rampas**. Carapicuíba/SP (apelidada "Caracas" pelos pilotos) é o coração histórico da modalidade — 15+ anos de gerações de BMX/DJ formadas no trabalho coletivo de manutenção dos trails.

**Implicação para a Patcho:** o "dig day" (dia de cavar) **é** o evento de comunidade mais barato e mais autêntico que existe. Custo quase zero, gera conteúdo (suor, terra, mãos sujas = "smells like dirt"), e quem cava ganha o patch. O jam é a festa; o dig day é a igreja.

### 1.3 Quem vem a um backyard jam em SC
- Núcleo local DJ/MTB de Garopaba/Imbituba/Rosa/Florianópolis (cena pequena, ~dezenas de pilotos sérios na microrregião).
- Pilotos de Floripa/Grande Floripa (1–1,5h de carro) e do eixo Criciúma/Tubarão.
- Surfistas-bikers (o overlap da cultura do Rosa é real).
- Realista para um primeiro jam de quintal: **15–40 pilotos + 30–80 espectadores/amigos**.

### 1.4 Cena DJ brasileira — onde a tribo já se reúne (canais a infiltrar)
- Grupos Facebook "Dirt Jump BRASIL" e "Dirt jump Bmx Brasil" (centenas/milhares de membros, ainda ativos).
- Hashtags: `#dirtjumpbrasil`, `#pumptrackbrasil`, `#dirtjumpsc`.
- **Trailforks** e **AllTrails** para mapear/registrar a trilha de Ibiraquera (24 km, MTB moderado) — vira pin oficial da Patcho.
- YouTube: cena registra muito (ex.: sessions de DJ filmadas na "pedreira" em SC, 2024). Conteúdo de vídeo é a moeda.

---

## 2. Custo real de rodar um backyard jam em SC (cenário pequeno, ~30 pilotos)

| Item | Faixa BRL | Nota |
|---|---|---|
| Terra/saibro p/ rampas (caçamba) | R$ 150–400/caçamba | 1–3 caçambas dependendo do estado dos trails; em terreno próprio, custo só de material |
| Diesel/combustível p/ retroescavadeira (se alugar) | R$ 0–600 | opcional; muito é feito na pá/enxada no dig day |
| Som (caixa Bluetooth grande / mini PA alugado) | R$ 100–300/dia | aluguel local |
| Água + gelo + isopor p/ a galera | R$ 150–300 | hidratação obrigatória |
| Kit primeiros-socorros + alguém com noção / brigadista informal | R$ 100–400 | gaze, soro, gelo instantâneo; ideal ter 1 socorrista |
| Patches/adesivos p/ distribuir (a "moeda" do parche) | R$ 300–900 | ver §3 — 30–50 patches + adesivos |
| Premiação simbólica (troféu artesanal / produto Patcho) | R$ 100–400 | NÃO precisa ser caro — o valor é simbólico (ver §5) |
| Filmagem/foto (amigo ou cachê baixo) | R$ 0–800 | conteúdo é o entregável real do evento |
| Comida (churrasco coletivo / food truck local) | R$ 0–600 | modelo "cada um traz algo" zera isso |
| **Seguro Acidentes Pessoais (recomendado)** | R$ 507–900 | ver §4 — apólice avulsa de evento |
| **TOTAL realista 1º jam** | **R$ 1.500–4.500** | sem seguro: R$ 1.000–3.500 |

**Modelo bootstrapped:** primeiro jam pode rodar por **~R$ 1.500** se: terreno é próprio/emprestado, comida é coletiva, filmagem é de um amigo, e a premiação é um patch + produto da própria marca. O gasto que NÃO se corta: água/socorro e os patches.

---

## 3. Patches & adesivos — a moeda da membresia

A Patcho dá patches; não vende (no início). O patch = "você é do parche". Isso é o que cria o desejo de compra depois.

### 3.1 Patch bordado personalizado (fornecedores BR, faixas reais 2025)
Fornecedores: **Eagle Patches**, **Linha Darte Bordados**, **Artgraf Etiquetas**, **MiMilon** (todos online, pedido mínimo a partir de ~10 un., enviam para SC via Correios/transportadora).

| Tamanho | 10 un. | 50 un. | 100 un. | 250 un. |
|---|---|---|---|---|
| 8 cm | ~R$ 16/un | ~R$ 14/un | ~R$ 11,75/un | ~R$ 11,33/un |
| 9 cm | ~R$ 17/un | ~R$ 15/un | ~R$ 12,75/un | — |
| 10 cm | ~R$ 18/un | ~R$ 16/un | ~R$ 13,75/un | ~R$ 13,33/un |

- Fixação: termocolante, Velcro® (combina com a cultura "patch trocável") ou liso p/ costura.
- Programação/digitalização do bordado: **grátis** na maioria; enviar vetor (.cdr/.ai) — a Patcho já tem o kit vetorial pronto.
- Variação de quantidade de ±10–20% é normal em pedido personalizado (orçar com folga).

### 3.2 Adesivos (a entrada mais barata na tribo)
Vinil/recorte ou impresso, fornecedores nacionais (gráficas online tipo Printi, gráficas locais de Tubarão/Floripa). Faixa típica: **R$ 0,50–2,00/un** em tiragens de 100–500. Adesivo é o "convite"; patch é o "diploma".

### 3.3 Hierarquia da membresia (gamificação da tribo)
1. **Adesivo** — qualquer um que segue/aparece. (custo ~R$1)
2. **Patch padrão** — quem cava no dig day ou roda no jam. (custo ~R$12–15)
3. **Patch numerado/edição** — entregue no jam anual / aos fundadores da cena. Raro, vira relíquia.
4. **O Selo** — o prêmio anual (ver §5).

---

## 4. Permissões, seguro e segurança — a realidade legal BR

### 4.1 A grande bifurcação: evento privado vs. evento público
**Evento privado, em terreno particular, sem venda de ingresso, sem patrocínio comercial ostensivo** = enquadra como **encontro/reunião de particulares**. Exigência regulatória mínima. Esse é o formato dos primeiros jams da Patcho.

**Evento aberto ao público / com ingresso / em espaço público** = aí entra a maquinaria pesada: **alvará da prefeitura, laudo do Corpo de Bombeiros (AVCB), comunicação à Polícia Militar, ART/laudo técnico de estrutura, seguro obrigatório**. Em SP a Lei 11.265/02 torna o seguro de Acidentes Pessoais **obrigatório** em eventos com ingresso — muitos municípios têm regra análoga. Cada prefeitura (Imbituba/Garopaba) tem suas próprias exigências — **consultar com antecedência**.

> **Recomendação:** manter os primeiros 2–4 jams no formato **privado/gratuito em terreno próprio ou emprestado**. Só migrar para evento público (com ingresso/patrocínio) quando houver caixa para a estrutura formal.

### 4.2 Seguro — mesmo no formato privado, contrate
Termo de responsabilidade assinado tem validade legal MAS **não substitui** seguro em acidente grave (e dirt jump é esporte de risco real). O organizador responde civil e penalmente por acidentes (Código Civil).

- **Seguro Acidentes Pessoais (AP) de evento — avulso, day use:** a partir de **R$ 507**, pagamento único, 100% digital, cobre participantes/staff/espectadores. Seguradoras: **Essor, AIG, Previsul, Prudential**; via **Sympla+Chubb** ("Evento Seguro") no checkout.
- **Por participante (modelo coletivo):** a partir de **~R$ 5/participante** (JSK Corretora e similares) — para 30 pilotos ≈ R$ 150+, mas com limites menores.
- **RC (Responsabilidade Civil) de evento:** seguradoras Akad, Tokio Marine, Berkley, Howden; limites de R$ 100 mil a R$ 1 mi. Mais caro; só faz sentido em evento público/grande.

**Para o jam de quintal:** AP avulso (R$ 507–900) + termo de responsabilidade assinado por todos + capacete obrigatório + socorrista de plantão = padrão de cuidado defensável.

### 4.3 Checklist de segurança mínimo do jam (não-negociável)
- [ ] Capacete obrigatório (sem capacete, não roda — e isso vira valor de marca).
- [ ] Termo de responsabilidade/risco assinado (menores: responsável legal).
- [ ] Kit primeiros-socorros + 1 pessoa designada / brigadista.
- [ ] Acesso para ambulância/carro mapeado (Imbituba: SAMU 192).
- [ ] Água/sombra/hidratação.
- [ ] Rampas inspecionadas antes (ART informal: alguém experiente valida).
- [ ] Seguro AP contratado (se houver qualquer público além dos amigos).

---

## 5. O "Selo Patcho" — o SOTY do dirt jump (a jogada de legitimidade)

### 5.1 Por que funciona para uma marca pequena
O SOTY da Thrasher provou: **o prêmio não precisa de dinheiro, precisa de código**. Critérios não-escritos, subjetivos, baseados em "andar radical e espontâneo" + respeito dos pares — não em resultado de prova. Custou uma festa de Natal em 1990; hoje é "o" prêmio. **Quem dá o prêmio primeiro, e com consistência, vira a autoridade** — porque ninguém estava dando antes.

No dirt jump BR **não existe um prêmio anual de cena com peso cultural**. Há vácuo. A Patcho pode ocupá-lo sendo a primeira a, com seriedade e estética, mintar legitimidade.

### 5.2 Como mintar legitimidade sendo minúsculo
1. **Júri de pares, não de marca.** O vencedor é escolhido por pilotos respeitados da cena (não pela Patcho). A marca é só a curadora/anfitriã. Isso compra credibilidade — exatamente o "input from other pro skaters" do SOTY.
2. **Critério explícito = autenticidade, não troféu.** Premiar: melhor line da temporada, trail building, espírito de comunidade, vídeo-parte do ano. Recompensa o que a cena valoriza, não o mais patrocinado.
3. **Entrega física que vira relíquia.** Um patch numerado + troféu artesanal (madeira/terra prensada/cerâmica local de SC — barato, ~R$ 100–400, e on-brand "loam"). A raridade > o custo.
4. **Documentar como ritual.** Filmar a entrega, lançar vídeo anual com as melhores cenas (espelha a Thrasher cobrindo a própria festa). O vídeo É o produto de marketing.
5. **Consistência > escala.** Fazer todo ano, na mesma época, no mesmo espírito. Tradição se constrói por repetição, não por orçamento.

### 5.3 Nome/formato (a confirmar com a marca)
- Ex.: **"Selo do Ano"** / **"Patcho Loam Award"** / **"Parche do Ano"**. Alinhar à voz bilíngue PT/EN.
- Cadência: 1x/ano, fim de temporada de verão SC (mar/abr — solo seco, jams cheios).
- Âncora física: o jam anual da Patcho como palco da entrega (o jam vira o "evento assinatura").

---

## 6. Parcerias regionais (SC / Garopaba / Imbituba)

### 6.1 Bike shops locais (primeiros aliados — co-marketing barato)
| Parceiro | Local | Jogada |
|---|---|---|
| **Nativus Bike Shop** | Av. Santa Catarina 980, Centro, Imbituba | ponto de apoio/manutenção; expor patches/adesivos no balcão; co-host de dig day |
| **Aro 3** | R. Francisco Pacheco de Souza 450, Garopaba | aluguel de bikes p/ visitantes; ponto de distribuição de adesivo |
| **Ao Sul Natural Turismo** | Alto Arroio, Imbituba (Rosa/Garopaba) | aluguel MTB + entrega; parceria p/ turismo-bike |

**Modelo:** não pedir dinheiro. Oferecer **conteúdo + presença**: a loja vira "casa do parche", ganha exposição nos vídeos da Patcho, expõe os patches. Win-win bootstrapped.

### 6.2 Eventos/cenas onde a Patcho deve APARECER (antes de criar o próprio)
- **Festival Brasil Ride** (calendário MTB nacional, 2026) — não é DJ, mas é onde a tribo MTB se concentra; ir como crew, distribuir adesivos, filmar.
- **Arena Freestyle / eventos de freestyle** — overlap de público radical.
- Sessions/jams informais já existentes em Floripa, Criciúma, e a "pedreira" SC — mandar a crew, dar patch pra quem brilha. **Sembrar antes de colher.**
- Cena de Carapicuíba/SP ("Caracas") — meca histórica; uma visita filmada = puro storytelling de raiz.

### 6.3 Riders regionais
Mapear 3–5 pilotos de DJ/freeride respeitados do eixo Floripa–Sul SC para serem os **primeiros embaixadores** (não pagos — recebem patch fundador + presença no conteúdo). Eles trazem a cena junto.

---

## 7. Roadmap de comunidade (12 meses, bootstrapped)

| Fase | Quando | Ação | Custo |
|---|---|---|---|
| 0. Semear | mês 1–2 | Entrar nos grupos FB/IG, mapear cena SC, dar adesivos em sessions existentes | ~R$ 200 (adesivos) |
| 1. Dig Day | mês 2–3 | Primeiro dia coletivo de cavar nos trails; filmar; dar patch a quem cava | ~R$ 400 |
| 2. Backyard Jam #1 | mês 3–4 | Jam privado, terreno próprio, ~30 pilotos, seguro AP, conteúdo | R$ 1.500–4.500 |
| 3. Parcerias | mês 4–6 | Fechar Nativus/Aro 3/Ao Sul como pontos de apoio | ~R$ 0 |
| 4. Embaixadores | mês 5–7 | 3–5 riders fundadores, patches numerados | ~R$ 300 |
| 5. Aparições | mês 6–10 | Crew presente em Brasil Ride / sessions regionais | viagem |
| 6. O Selo (1ª ed.) | ~mês 11–12 (mar/abr) | Jam anual + entrega do prêmio anual + vídeo | R$ 3.000–6.000 |

---

## 8. Riscos & questões abertas
- **Risco legal/acidente:** dirt jump tem lesão real. Subseguro = exposição civil/penal do casal. Não economizar em AP + termo + socorro.
- **Risco de "comprar" comunidade:** se a Patcho parecer marca extraindo da cena (em vez de servir), a tribo rejeita (vide debate "poser" da Thrasher). Antídoto: dar antes de pedir; júri de pares; fundadores não-pagos por respeito, não por dinheiro.
- **Sazonalidade SC:** verão (dez–abr) = solo seco, jams cheios. Inverno chuvoso = trails molhados, foco em conteúdo/dig.
- **A confirmar:** exigências específicas de alvará das prefeituras de **Imbituba e Garopaba** para evento privado x público (consultar diretamente).
- **A confirmar:** terreno disponível do casal/parceiros com espaço e acesso para rampas + estacionamento.

---

## Sources
- [Como organizar evento / alvará — Sympla, Lets, Atletis, ESSP](https://blog.sympla.com.br/blog-do-produtor/alvara-para-eventos/)
- [Seguro evento esportivo amador — Howden, Akad, Tokio Marine, JSK (a partir de R$5/participante)](https://jskcorretora.com.br/seguro-para-eventos-esportivos/)
- [Seguro AP evento day use a partir de R$507 — Essor, AIG, Previsul, Sympla+Chubb](https://www.essor.com.br/seguros/seguro-eventos/)
- [Thrasher SOTY — origem, critérios, legitimidade (Surfertoday, Jenkem, Board Blazers)](https://www.surfertoday.com/skateboarding/thrasher-skater-of-the-year-the-complete-winners-list)
- [Patch bordado preços BR — Eagle Patches, Linha Darte, Artgraf, MiMilon](https://www.eaglepatches.com.br/patch-bordado-personalizado-com-programacao-gratuita-9-cm)
- [Bike shops SC — Nativus (Imbituba), Aro 3 (Garopaba), Ao Sul Natural](https://www.planetabrasileiro.com/nativus-bike-shop-F170FC80E1ED245)
- [Cena DJ/freeride BR — Carapicuíba "Caracas", trail building coletivo (Isapa, Tudo Sobre Ciclismo)](https://www.isapa.com.br/bike/2024/06/20/bike-radical-conheca-melhor-dirt-jump-freeride-e-pump-modalidades-arrojadas-em-duas-rodas/)
- [Trilhas Ibiraquera/Garopaba — AllTrails, Trailforks, Wikiloc, Komoot](https://www.alltrails.com/pt-br/trilha/brazil/santa-catarina--2/ibiraquera-garopaba)
- [Grupos DJ Brasil — Facebook "Dirt Jump BRASIL"](https://www.facebook.com/groups/637087126334680/)
