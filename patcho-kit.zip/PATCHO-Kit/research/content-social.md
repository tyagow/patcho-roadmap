# Conteúdo & Social — O Motor de Crescimento da Patcho

> Pesquisa interna · Junho 2026 · Patcho (Tiago & Jaluza) · Ibiraquera/Imbituba, SC
> Tese: **não estamos abrindo uma marca de roupa — estamos filmando uma história que por acaso vende patches.** Conteúdo + comunidade vêm primeiro; produto segue. O patch = carteirinha do "parche" (a crew).

Este documento é o plano do **motor de conteúdo**, que é o real *growth lever* da marca. Tudo aqui parte de uma realidade: somos **duas pessoas, bootstrapped, no quintal**. Cadência sustentável ganha de cadência heroica.

---

## 1. O princípio que governa tudo: abrir no *send*, não no logo

A regra das plataformas em 2026 não mudou — endureceu. O *scroll-stop* acontece nos **primeiros 3 segundos**, e a maior parte da desistência é entre os segundos 0–3. ~71% dos espectadores decidem nos primeiros segundos se continuam. Para conteúdo de build/ride, isso é uma vantagem brutal: a gente tem munição visual que niche de "talking head" não tem.

**Regras de primeiro frame (valem para Reels, TikTok e Shorts):**

- **Abra no momento mais explosivo** — o *send* de cima do lip, o whip do drop, o quase-acidente. NUNCA abra com logo, "fala galera" ou intro.
- **Hook multimodal:** visual (pattern interrupt) + texto na tela (4–7 palavras, alto contraste, safe zone) + áudio (palavra-chave falada). 85% assiste sem som — o texto precisa carregar o hook sozinho.
- **Pattern interrupt no segundo 1:** corte seco, whip-pan, snap-zoom, ângulo desorientante. POV de crash funciona demais.
- **Curiosity gap:** abrir um loop que só fecha no fim. _"Esse lip já cuspiu a gente 3 vezes…"_ / _"Ninguém anda essa linha por um motivo…"_
- **Meta de retenção:** no YouTube Studio/Insights, mire **"Viewed vs. Swiped Away" ≥ 75%** e curva de retenção sem queda brusca no segundo 3.

**Framework de roteiro (testado em 100k+ vídeos virais):** Hook → Problema/Tensão → Payoff → CTA. Reels improvisados perdem força em 2026; conteúdo com micro-roteiro retém mais. Isso NÃO contradiz a estética crua da Patcho — roteiro aqui = saber qual é o hook e o payoff antes de gravar, não produção engessada.

**Padrões de hook que funcionam para build/ride (banco de ideias):**

| Tipo de hook | Exemplo Patcho (PT) | Exemplo Patcho (EN) |
|---|---|---|
| Visual pattern interrupt | Snap-zoom no topo do drop | Snap-zoom into the lip |
| Curiosity gap | "Esse lip quase acabou com o dia" | "This lip almost ended the session" |
| Problema/Solução | "Sua roda da frente lava no lip — faz assim" | "Front wheel washing out? Do this" |
| Open loop | "No fim dessa linha eu quase não fiz…" | "By the end of this line…" |
| Before/After | Terra crua → lip moldado e batido | Raw dirt → shaped, sessioned lip |

---

## 2. Instagram Trial Reels — laboratório de hooks com não-seguidores

Trial Reels é o recurso mais subestimado para uma conta começando do zero. Ele é, na prática, **A/B testing de hook de graça contra público frio.**

**Como funciona (estado 2026):**
- Disponível para contas públicas com **1.000+ seguidores** (limitação importante — ver abaixo). No share final, ativar o toggle **Trial**.
- O Reel **não aparece no seu grid** nem para seus seguidores. O Instagram empurra para **não-seguidores** e mede 24–72h.
- Depois reporta: views, watch time, shares, saves, **alcance de não-seguidores**. Você decide publicar de verdade ou descartar (some sem prejudicar o perfil).
- **Auto-share** se performar bem em ~72h; e desde **fev/2026** dá para **agendar Trials em lote** — perfeito para uma dupla bater uma semana de testes num sentar só.
- Dado oficial: 40% dos criadores que testam Trials passam a postar mais Reels, e 80% desses veem mais alcance com não-seguidores.

**A ressalva honesta (Mosseri confirmou):** Trial Reels quase sempre têm **menos alcance** que Reels normais, porque não pegam o boost inicial de engajamento dos seguidores. **North stars = watch time e share rate**, não curtidas.

**Implicação para a Patcho:** Trials só destravam aos 1.000 seguidores. **Fase 0 (0→1k):** postar Reels normais e usar a aba de Insights para ler hook performance manualmente. **Fase 1 (1k+):** virar Trials no modo laboratório — testar 3–5 hooks/semana contra público frio, manter só os vencedores no grid. Isso preserva a estética curada do feed (Loam Premium) enquanto testa agressivamente nos bastidores.

---

## 3. YouTube long-form "The Backyard Build" + corte em verticais

A peça âncora de conteúdo: **YouTube long-form como fábrica de matéria-prima**, do qual se extraem dezenas de verticais. Um vídeo de build/ride de 8–20 min vira **10–20 cortes publicáveis** (Reels/TikTok/Shorts).

**Por que long-form importa mesmo com poucos inscritos:** o nicho dirt-jump tem precedentes claros — canais de "dream builds" e build-timelapse meditativos chegaram a 1M+ inscritos com formato lento e bonito. O long-form constrói a *história* (a tese da marca); os cortes constroem o *alcance*.

**Pipeline de repurpose para uma dupla (stack recomendada):**

1. **Pessoa A — geração de cortes:** subir o MP4/URL no **Opus Clip** (ClipAnything detecta momentos fortes mesmo em vídeo de ação, ReframeAnything reenquadra para 9:16, legendas 97%+). Opus é otimizado para fala limpa — em conteúdo de ação com narração/voz, mire o subset de clipes com fala clara.
2. **Pessoa B — refino e branding:** **CapCut** para ajustar duração, legenda no tom Patcho (PT/EN), grão de filme, marca d'água discreta, export multi-plataforma.
3. **vidIQ (opcional):** camada de SEO/keyword para títulos e descrições no YouTube.

**Custos do toolstack (BRL, mid-2026):**
- Opus Clip Starter ~US$15/mês (~R$ 80–95/mês) para começo; Pro ~US$29/mês (~R$ 155–185/mês) quando o volume crescer.
- CapCut: tier grátis cobre muito; CapCut Pro ~R$ 25–45/mês se precisar de recursos avançados/sem marca d'água.
- Sweet spot de duração do corte: **30–60s** (boost algorítmico em TikTok/Shorts); para Reels, 15–30s entrega maior engajamento (5,8%).

---

## 4. Séries recorrentes — a espinha dorsal editorial

Séries dão identidade ao canal, criam expectativa e clusterizam o conteúdo (o algoritmo de 2026 recompensa consistência dentro do nicho — "3 vídeos focados num tema batem 7 espalhados").

| Série | Formato | Cadência | Plataforma primária |
|---|---|---|---|
| **The Backyard Build** | Long-form: moldar/refazer o lip no quintal, timelapse + sessão | Quinzenal | YouTube → cortes verticais |
| **Foam to Dirt** | Truque novo: do foam pit (segurança) à terra real | Semanal | Reels/TikTok/Shorts |
| **Wipeout Wednesday** | Compilado de quedas + o que deu errado/aprendizado | Semanal (qua) | Reels/TikTok — alto share |
| **His & Hers** | Tiago vs. Jaluza na mesma linha/desafio — dual POV | Quinzenal | Reels — humaniza o casal |
| **Sunset Session** | B-roll cinematográfico mata atlântica/Ibiraquera, mood | Semanal/oportunista | Reels/Stories — alma Loam |

A série **His & Hers** é estratégica: o casal É o diferencial narrativo. Comunidades de nicho engajam 3–6% (vs. média de plataforma ~0,48%) justamente porque há *pessoas* e *pertencimento*, não só esporte.

---

## 5. Cadência sustentável para 2 pessoas

Dado de 11M+ posts: o salto de eficiência é de **1 → 2–5 posts/semana** (até +17% views/post). Acima de 10/semana = retornos decrescentes + burnout. Consistência > frequência: 3/semana toda semana ganha de 7 num dia e sumir.

**Plano realista Patcho (vertical + long-form):**

| Plataforma | Cadência alvo | Notas |
|---|---|---|
| Reels (IG) | 3–5/semana | Cortes do build + séries. Era da "atualidade": Meta mostra +50% Reels de quem postou no mesmo dia |
| TikTok | 3–5/semana | Mesmos cortes, legenda adaptada; TikTok virou search engine → keywords na legenda + texto na tela |
| YouTube Shorts | 3–5/semana | Cortes reaproveitados; vidIQ para SEO |
| YouTube long-form | quinzenal | The Backyard Build — peça âncora |
| IG Stories | 1–2/dia | Bastidores, enquetes, CTA. Mantém o "parche" vivo |
| IG Carrossel | 1/semana | "Dignos de salvar": tutorial de lip, gear, mapa de trilha. Carrossel lidera em saves |

**Sistema de produção (batch):** uma sessão de filmagem no quintal alimenta semanas. Gravar pesado, depois Opus/CapCut em lote. Agendar Trials em lote (fev/2026). Isso é o que torna 14–20 peças/semana viável para 2 pessoas sem queimar.

---

## 6. SEO > hashtags, descoberta e alcance global

- **SEO supera hashtags em 2026:** palavras-chave na legenda, no texto-alt e no texto-na-tela rankeiam na busca (TikTok e IG). Conteúdo evergreen ganha cauda longa de dias/semanas. Usar hashtags de **micro-nicho** (menos concorridas): #dirtjump #pumptrack #bikelife #trilhasc #mtbbrasil em vez de #bike genérico.
- **Bilíngue PT/EN é arma de alcance:** dublagem automática de Reels amplia alcance global; legenda/texto em PT primário com termos EN naturais (já é a voz da marca) torna o conteúdo globalmente legível sem perder a alma brasileira.
- **Não comprar seguidores/curtidas:** o algoritmo de 2026 pune com rigor (shadowban médio de 14 dias; ~14% dos seguidores na plataforma são bots/inativos). Crescimento artificial distorce a audiência e derruba o ER.

---

## 7. Expectativas realistas de 90 dias (do zero, neste nicho)

Honestidade total: **crescimento de seguidor é lento; engajamento é o que importa cedo.** Não vender ilusão de viral.

**Benchmarks de engajamento (2026):**
- Média da plataforma: ~0,48% por seguidores (caiu 24% YoY).
- **Nano (1k–10k): ER médio 6,23%** — o maior de todos os tiers. Comunidades de nicho passam de 3% fácil.
- Reels: 4,2–7,1% de ER (vs. feed 2,1–3,2%). Reels 15–30s = 5,8%.
- Crescimento orgânico saudável: **1–3% ao mês compondo** (a base; picos virais não sustentam).

**Cenários honestos de 90 dias (do zero, dupla, nicho dirt-jump, cadência 3–5 Reels/sem + quinzenal long-form):**

| Cenário | Seguidores IG @ 90d | Inscritos YT @ 90d | Sinal de saúde |
|---|---|---|---|
| Conservador (consistência sem viral) | 300–800 | 100–300 | ER ≥ 4%, watch time subindo |
| Base (1–2 cortes performando bem) | 800–2.000 | 300–800 | Cruzar 1k IG → destrava Trials |
| Otimista (1 corte estourou + comunidade) | 2.000–5.000+ | 800–2.000+ | Saves/shares altos, DMs de "warm leads" |

**O número que importa não é seguidor — é o "parche":** DMs, comentários recorrentes, saves, gente comentando "qual o nome da trilha?". Esses são os primeiros membros da crew, e a base de quem compra o primeiro patch. Medir: watch time, share rate, save rate, taxa de não-seguidor alcançado, e tamanho do núcleo engajado (comentaristas recorrentes), NÃO follower count bruto.

**Marco-chave dos 90 dias:** cruzar **1.000 seguidores no IG** para destravar Trial Reels e mudar de "ler hooks na mão" para "testar hooks em escala". Esse é o objetivo numérico real do trimestre.

---

## 8. Comportamento da audiência MTB/dirt-jump (BR + global)

- **Micro-nicho leal:** público pequeno mas apaixonado, cultura de "construa sua própria trilha". Engaja em build, gear, quase-acidente, e *autenticidade* — não em produção polida demais.
- **Brasil-first com leitura global:** cena SC (surf+bike, mata atlântica) é diferencial visual raro no feed global. Trilhas/regiões específicas (#trilhasc) entregam ao público certo.
- **Saves e shares > likes:** conteúdo "digno de salvar" (tutorial de lip, mapa, gear list) constrói profundidade; share é o sinal de alcance.
- **Comunidade > viralização:** o crescimento sustentável de 2026 vem de conexão profunda. Para a Patcho isso é literalmente a tese — o conteúdo constrói a tribo, a tribo compra o patch.

---

## Sources

- [Fliki — Trial Reels: How They Work + 12 Tests (2026)](https://fliki.ai/blog/trial-reels-instagram)
- [Publer — Instagram Trial Reels Guide (2026)](https://publer.com/blog/instagram-trial-reels-guide/)
- [Leslie M Lyon — Trial Reels 89% Non-Follower Reach](https://lesliemlyon.com/instagram-trial-reels-strategy/)
- [Cloudix — 3-Second Hook Rule for 2026](https://cloudixdigital.com/short-form-video-mastery-how-the-3-second-hook-rule-drives-social-discovery-and-roi/)
- [Virvid — First 3 Seconds Hook Structures (2026)](https://virvid.ai/blog/first-3-seconds-hook-faceless-shorts-2026)
- [Conbersa — Best YouTube Shorts Hooks & Formats 2026](https://www.conbersa.ai/learn/best-youtube-shorts-hooks)
- [Buffer — How Often to Post on TikTok (11M+ posts)](https://buffer.com/resources/how-often-should-you-post-on-tiktok/)
- [JoinBrands — How Often to Post on TikTok 2026](https://joinbrands.com/blog/how-often-to-post-on-tiktok/)
- [Rafael Terra — 15 Tendências e Estratégias para Reels em 2026](https://rafaelterra.com.br/como-viralizar-reels-em-2026/)
- [Nikau — Algoritmo do Instagram 2026](https://nikau.com.br/blog/algoritmo-do-instagram-2026-estrategias-para-crescer-e-engajar/)
- [Socialinsider — 2026 Instagram Organic Engagement Benchmarks](https://www.socialinsider.io/social-media-benchmarks/instagram)
- [Influencer Marketing Hub via Nowadays — Engagement Benchmarks 2026](https://nowadays.media/blog/influencer-engagement-rate-benchmarks-2026-by-platform-niche-follower-tier/)
- [OpusClip — Short-Form Video Strategy 2026](https://www.opus.pro/blog/short-form-video-strategy-2026)
- [CapCut — Top AI Tools to Turn Long Videos into Shorts (2026)](https://www.capcut.com/resource/top-8-tools-for-turning-long-videos-to-shorts)
- [Feedspot — 15 Dirt Jumping YouTubers (2026)](https://videos.feedspot.com/dirt_jumping_youtube_channels/)
- [BikeMag — Best Mountain Biking YouTube Channels](https://www.bikemag.com/news/mtb-youtube-channels)
