# PATCHO — Legal, Marca & Estrutura (Brasil)

> Pesquisa interna · mid-2026 · todos os valores em BRL (R$)
> Base: Ibiraquera / Imbituba (SC). Couple founders: Tiago & Jaluza.
> Escopo: registro de marca no INPI · domínios (registro.br + .com) · estrutura jurídica para vender legalmente e emitir nota fiscal.

---

## TL;DR (o mínimo para operar legal)

1. **Abrir MEI** (CNAE principal **4781-4/00 — comércio varejista de vestuário**) → custa R$ 0 para abrir, R$ ~76,90/mês de DAS, permite **emitir nota fiscal** e vender legalmente em loja própria + marketplaces. Teto **R$ 81.000/ano**.
2. **Registrar a marca "PATCHO" no INPI** — classe **25 (vestuário)** como prioridade. Com desconto MEI/ME: **R$ 440/classe**. Depositar como **marca mista** (nome + emblema) OU **nominativa** (só nome). Timeline realista até concessão: **8–18 meses** sem oposição.
3. **Registrar domínios** — `patcho.com.br` no **registro.br** por **R$ 40/ano**; `patchoco.com` numa registradora internacional por **R$ 30–110/ano**.

Custo de entrada total no dia 1 (MEI grátis + 1 classe INPI + 2 domínios): **≈ R$ 510–590**, mais ~R$ 77/mês de DAS.

---

## 1. INPI — Registro da marca "PATCHO"

### 1.1 Por que registrar
O registro no INPI dá **exclusividade nacional por 10 anos** (renovável indefinidamente por períodos de 10 anos) sobre o uso da marca na(s) classe(s) registrada(s). Sem registro, qualquer outro pode registrar "PATCHO" antes de você e te obrigar a parar de usar — risco real e fatal para uma brand cujo ativo central É o nome. O protocolo (depósito) já cria **anterioridade** e é o que importa: registre cedo.

### 1.2 Classes de Nice — o que proteger
A Classificação de Nice tem 45 classes (1–34 produtos, 35–45 serviços). Para a PATCHO:

| Classe | O que cobre | Prioridade |
|--------|-------------|------------|
| **25** | Vestuário, calçados, chapelaria — **camisetas, bonés, moletons, jaquetas** | **ESSENCIAL — depositar já** |
| **26** | Rendas, fitas, **emblemas/patches bordados** (passamanaria) — o "patch" físico se vendido avulso | Recomendado se o patch for produto-âncora vendido solto |
| **35** | Serviços de comércio/varejo, publicidade, gestão de loja online | Opcional — protege a operação de e-commerce/marca como varejista |
| **41** | Educação, **entretenimento, produção de conteúdo audiovisual** | Opcional — coerente com a tese "filmamos uma história" (vídeos, edits, canal) |

**Recomendação Loam-Premium realista (bootstrapped):**
- **Fase 1 (agora):** depositar **classe 25** apenas. É onde está o produto e o maior risco de colisão. 1 classe.
- **Fase 2 (quando houver caixa / quando o patch virar SKU avulso):** adicionar **classe 26** (patches) e, se o conteúdo crescer e virar receita/IP a defender, **classe 41**. A **35** só vale a pena se você quiser blindar a marca como operação de varejo/loja — geralmente dispensável no começo.

> Cada classe é um pedido (GRU) separado e some no custo. Não "carregue" classes que você não vai usar — o INPI exige uso efetivo e marca não usada pode ser alvo de **caducidade** após 5 anos.

### 1.3 Forma de apresentação — qual depositar
- **Nominativa** (só a palavra "PATCHO"): protege o **nome** independentemente de fonte/cor/logo. Máxima flexibilidade — você pode reestilizar o emblema quando quiser sem perder proteção. **Mais forte para o ativo "nome".**
- **Mista** (nome + emblema/lip icon juntos): protege nome **e** o desenho estilizado em conjunto, mas atrelados.
- **Figurativa** (só o símbolo — o ícone "lip"/emblema): protege o desenho, não o nome.

**Recomendação:** o ativo nº 1 da PATCHO é o **nome**. Idealmente depositar **nominativa (PATCHO)** para blindar o nome + **figurativa** do emblema se houver orçamento. Se for escolher **uma só** por custo, muitos especialistas recomendam **mista** para um negócio que já tem logo consolidado — mas para uma brand que ainda pode evoluir o visual, **nominativa** dá mais liberdade. Mesmo custo para qualquer forma. **Minha sugestão: começar nominativa (nome) + figurativa (emblema) = 2 pedidos na classe 25**, OU se apertar, só **mista**.

### 1.4 Custo oficial (GRU / retribuição) — 2026
Tabela vigente desde ago/2025, **taxa única** (sem cobrança extra na concessão):

| Requerente | Por classe (depósito) |
|------------|----------------------|
| **MEI / ME / EPP** (com desconto de 50%) | **R$ 440** |
| Demais (PF sem enquadramento, grandes empresas) | **R$ 880** |

- Pagamento via **GRU gerada no sistema e-Marcas** do próprio INPI. **Só o Tesouro Nacional recebe** — GRU por WhatsApp/e-mail com conta privada é **golpe**.
- O desconto MEI/ME **não é automático**: precisa ser informado e comprovado na hora de gerar a GRU. Errou/não comprovou → INPI pode cancelar e cobrar o valor cheio. **Abrir o MEI ANTES de depositar a marca** garante o desconto de 50%.

**Custo INPI por cenário (com desconto MEI):**
- Só classe 25, 1 forma (mista): **R$ 440**
- Classe 25 nominativa + figurativa: **R$ 880**
- Classe 25 + 26 + 41 (1 forma cada): **R$ 1.320**

### 1.5 Passo a passo (e-Marcas)
1. Criar cadastro/login gov.br no **e-Marcas** (sistema do INPI).
2. **Busca de anterioridade** — pesquisar "PATCHO" (e variações fonéticas: PACHO, PATCHÔ, PATCH) nas classes-alvo para checar colisão. Grátis, na base do INPI. Etapa crítica antes de pagar.
3. Preencher o formulário: requerente (CNPJ do MEI), classe, especificação dos produtos, forma de apresentação, e (se mista/figurativa) **upload da imagem do logo**.
4. Gerar a **GRU** informando o **enquadramento MEI** (desconto 50%) e pagar (app do banco / internet banking / lotérica). INPI confirma em até 3 dias úteis.
5. Protocolar o pedido → **número de processo gerado na hora** (anterioridade garantida).
6. Acompanhar a **RPI (Revista da Propriedade Industrial)** — publicação abre **60 dias corridos de oposição**.
7. Sem oposição → **exame de mérito** → concessão → emissão do certificado.

### 1.6 Timeline realista até concessão
| Cenário | Prazo |
|---------|-------|
| Sem oposição, sem exigência | **8–15 meses** |
| Processo padrão | 18–24 meses |
| Com oposição/exigência técnica | 24–36+ meses |
| Etapa mais longa: exame de mérito | média ~16 meses |

**O que o depósito (as-filed) já te dá:** anterioridade desde o dia do protocolo + direito de usar a marca com o símbolo "MD" (marca depositada). A **exclusividade plena** e o direito de uso do ® só vêm com a **concessão**. Pode-se usar e vender com o pedido em andamento, mas **não invista pesado em estoque/comunicação sob a marca antes de avaliar o risco de colisão** (use a busca de anterioridade para reduzir esse risco).

### 1.7 Notas regionais (SC)
Registro de marca é **federal** (INPI), 100% online — não muda por estar em Imbituba/Ibiraquera. Não precisa de agência local; dá para fazer sozinho no e-Marcas. Advogado/agente de PI é opcional (custa R$ 800–2.500 de honorário por marca) e útil se houver risco de oposição ou nome "limítrofe".

---

## 2. Domínios

| Domínio | Onde registrar | Preço 2026 | Observação |
|---------|----------------|-----------|------------|
| **patcho.com.br** | **registro.br** (oficial) | **R$ 40/ano** (R$ 34,80/ano se 5 anos = R$ 174) | Privacidade WHOIS inclusa para PF. Sem renovação-surpresa. |
| **patchoco.com** | Registradora internacional (Hostinger, Namecheap, GoDaddy, Cloudflare) | **R$ 30–110/ano** (1º ano), renovação R$ 55–110/ano | Atenção: 1º ano barato → renovação cara em alguns provedores. Cloudflare vende a preço de custo (~US$ 9–10). |

- **registro.br** exige **CPF ou CNPJ brasileiro** — você já tem. .com.br é o domínio mais forte para o público BR.
- Para o `.com` global, prefira provedor com **WHOIS privacy grátis** (GoDaddy, Cloudflare, Namecheap) — evita expor endereço residencial.
- **Recomendação:** registrar `patcho.com.br` por **5 anos** (trava o nome + preço, R$ 174) e `patchoco.com` por 1–2 anos para começar. Custo combinado: **≈ R$ 205–290** para 5 anos + 1 ano.

---

## 3. Estrutura jurídica — vender legal e emitir nota fiscal

### 3.1 MEI — o ponto de partida certo
Para uma brand bootstrapped começando, o **MEI é o setup mínimo e suficiente** para vender legalmente e emitir NF.

| Item | Valor 2026 |
|------|-----------|
| Custo de abertura | **R$ 0** (online, Portal do Empreendedor) |
| Teto de faturamento | **R$ 81.000/ano** (~R$ 6.750/mês) |
| DAS mensal (comércio) | **R$ 76,90** (R$ 75,90 INSS + R$ 1,00 ICMS) |
| Emite nota fiscal | **Sim** (com CNPJ) |
| Empregados | até 1, máx. 1 salário mínimo |

- **CNAE principal:** **4781-4/00 — Comércio varejista de artigos do vestuário e acessórios.** Cobre revenda/venda de camisetas, bonés, moletons, patches, acessórios — em loja física, e-commerce, marketplaces e redes sociais.
- **Nota fiscal:** obrigatória em venda para **PJ** (empresa com CNPJ); **facultativa** para consumidor PF (mas recomendável emitir sempre). Normalmente exige **Inscrição Estadual** (SEF/SC) para emitir NF-e de mercadoria.
- Pode ter até **16 atividades** (1 principal + 15 secundárias), todas dentro da lista MEI.

### 3.2 ⚠️ Armadilha: fabricação própria de roupa NÃO cabe no MEI padrão
Se a PATCHO **fabricar** as peças (corte/costura próprios em escala), o CNAE é **1412-6/01 — Confecção de peças de vestuário** que **NÃO está na lista de ocupações permitidas ao MEI**. Apenas o **1412-6/02 — confecção SOB MEDIDA** (costureiro/alfaiate sob encomenda) é MEI-elegível, e não é o modelo da PATCHO (small batches, não sob medida).

**Implicação prática (modelo realista da PATCHO):**
- Se você **terceiriza a produção** (manda fazer em confecção/estampador e revende sob sua marca) → você é **comércio (4781-4/00)** → **MEI funciona**. Este é o caminho bootstrapped padrão e o recomendado.
- Se você **fabrica em escala internamente** → precisa de **ME** com CNAE 1412-6/01 (Anexo II/III do Simples), não MEI.

> Para o estágio atual (small batches, terceirizar costura/estampa, vender sob a marca), **MEI como comércio (4781-4/00) é legal e suficiente.** Confirme com contador qual CNAE secundário declarar se houver dúvida sobre "industrialização por encomenda".

### 3.3 Quando migrar para ME / Simples Nacional
Você **deve desenquadrar do MEI** quando:
- Faturar **> R$ 81.000/ano** (acima de 20% do teto, i.e. > R$ 97.200, o desenquadramento é retroativo e gera multa).
- Quiser **fabricar em escala** (CNAE de confecção fora do MEI).
- Precisar de **mais de 1 funcionário**.

**ME no Simples Nacional (comércio de vestuário):**
| Item | Valor 2026 |
|------|-----------|
| Anexo | **Anexo I (comércio)** |
| Alíquota efetiva inicial (1ª faixa, até R$ 180k) | **4%** sobre o faturamento |
| Faixas | 6 faixas, de 4% até 19% conforme RBT12 |
| Teto Simples | **R$ 4,8 milhões/ano** |
| Impostos unificados no DAS | IRPJ, CSLL, Cofins, PIS/Pasep, CPP, ICMS |
| Custo de contador (mensal) | **R$ 150–400/mês** (contabilidade digital) |
| Abertura ME | Junta Comercial SC + alvará Imbituba — **R$ 200–800** + honorário contábil |

Se for **fabricação própria**, o enquadramento tende ao **Anexo II** (indústria, também 4% inicial) ou **Anexo III** (serviço sob medida, 6% inicial) — confirmar com contador.

### 3.4 Recomendação de estrutura
1. **Agora:** abrir **MEI** como **comércio (4781-4/00)**, produzir terceirizado em small batches, vender sob a marca. Custo: R$ 0 abertura + R$ 77/mês.
2. **Gatilho de migração:** ao se aproximar de ~R$ 70k/ano de faturamento OU ao internalizar produção → migrar para **ME Simples Nacional (Anexo I)** com contador.
3. Manter o CNPJ do MEI como **requerente da marca no INPI** (garante o desconto de 50%).

---

## 4. Checklist de ação (ordem recomendada)

1. [ ] Abrir **MEI** (4781-4/00) no Portal do Empreendedor → CNPJ na hora, grátis.
2. [ ] Solicitar **Inscrição Estadual** (SEF/SC) para emitir NF-e de mercadoria.
3. [ ] **Busca de anterioridade** "PATCHO" no e-Marcas (classes 25/26/41).
4. [ ] **Depositar marca classe 25** (nominativa + figurativa, ou mista) com **desconto MEI** → R$ 440–880.
5. [ ] Registrar **patcho.com.br** no registro.br (5 anos = R$ 174) + **patchoco.com** internacional.
6. [ ] Configurar emissão de NF-e (emissor gratuito SEBRAE/SEF-SC ou plataforma da loja).
7. [ ] (Futuro) Adicionar classes 26/41 no INPI quando patch avulso / conteúdo virarem ativos a defender.

---

## Sources

- [INPI — Custos e Pagamento (oficial)](https://www.gov.br/inpi/pt-br/servicos/marcas/custos)
- [INPI — Manual de Marcas, Emissão e pagamento da GRU](https://manualdemarcas.inpi.gov.br/projects/manual/wiki/3%C2%B703_Emiss%C3%A3o_e_pagamento_da_GRU)
- [INPI — Perguntas e Respostas / Precificação dos serviços](https://www.gov.br/inpi/pt-br/inpi-data/precificacao-dos-servicos/PerguntaseRespostas)
- [Custo do registro de marca no INPI em 2026 (oficialmarca.com.br)](https://oficialmarca.com.br/blog/quanto-custa-registrar-marca-2026/)
- [Prazo médio do registro de marca no INPI 2026 (oficialmarca.com.br)](https://oficialmarca.com.br/blog/quanto-tempo-demora-registro-marca-inpi/)
- [Marca nominativa, mista e figurativa — diferenças (jusbrasil)](https://www.jusbrasil.com.br/artigos/como-identificar-marca-nominativa-mista-e-figurativa-no-inpi/2236105247)
- [CNAE 4781-4/00 — comércio varejista de vestuário: MEI e Simples (contabilidade.com)](https://contabilidade.com/blog/cnae-4781400-comercio-varejista-de-artigos-do-vestuario-e-acessorios-pode-ser-mei-quanto-paga-e-quando-desenquadrar-do-mei/)
- [MEI 2026 — limite de faturamento e regras (Contmatic Simplifique)](https://simplifique.contmatic.com.br/blogs/mei-2026-limite-faturamento-o-que-muda)
- [Guia MEI para vender roupas 2026 (Nuvemshop)](https://www.nuvemshop.com.br/blog/qual-mei-para-vender-roupas/)
- [CNAE 1412-6/01 confecção de vestuário (Contabilizei)](https://www.contabilizei.com.br/consulta-cnae/cnae-confeccao-de-artigos-do-vestuario-e-acessorios/1412601-confeccao-de-pecas-de-vestuario-exceto-roupas-intimas-e-as-confeccionadas-sob-medida/)
- [Atividades MEI 2026 — tabela CNAE permitidas (Contabilizei)](https://www.contabilizei.com.br/contabilidade-online/atividades-mei-tabela/)
- [Simples Nacional 2026 — Anexo I comércio (Contabilizei)](https://www.contabilizei.com.br/contabilidade-online/anexo-1-simples-nacional/)
- [Pagamento de domínio (registro.br oficial)](https://registro.br/ajuda/pagamento-de-dominio/)
- [Quanto custa um domínio em 2026 (HostGator)](https://www.hostgator.com.br/blog/quanto-custa-um-dominio/)
- [Domínio .com.br barato 2026 — renovação (techub.digital)](https://techub.digital/blog/article/dominio-combr-barato-em-2026-onde-registrar-sem-tomar-susto-na-renovacao)
