# Manufatura & Sourcing — Patcho

> Pesquisa interna · jun/2026 · base BRL (R$), USD secundário
> Brand: Patcho — dirt-jump lifestyle, bootstrapped. Home base: Ibiraquera / Imbituba, SC.
> Direção: **Loam Premium** — peças refinadas que "cheiram a terra". Restrição = qualidade.

---

## TL;DR — o que produzir PRIMEIRO

A ordem de produção segue o princípio "o objeto físico mais barato que carrega a marca e funciona como **selo do parche**":

1. **Adesivo de vinil (sticker)** — primeiro objeto físico. Milheiro custa ~R$ 200–500. Custo unitário centavos. Já é "membership token" distribuível em qualquer trilha/evento. Faça AGORA.
2. **Patch bordado** (o produto-âncora da marca) — MOQ real 10 un, mas o ponto doce é 50–100 un. ~R$ 9–16/un a 100. É o coração do "parche".
3. **Boné dad-cap com patch de couro gravado a laser ou bordado** — MOQ 24–25 un, ~R$ 22–40/un. Alto valor percebido, cara da marca.
4. **Camiseta pesada** — comece com fornecedor SC (Lunfe/Monte Leste) + estampa terceirizada OU POD (Dimona) para validar artes sem estoque. Batch quando a arte provar venda.
5. **Moletom** — último, é o item de maior capital imobilizado (MOQ 30 un × ~R$ 50–90 blank + estampa).

**Estratégia bootstrapped:** POD (Dimona/Montink) para VALIDAR artes de camiseta/moletom sem risco de estoque → migrar para **batch local** (SC) os modelos que venderem, onde a margem premium aparece. Patches/bonés/stickers SEMPRE em batch (não existe POD bom para eles e são o core).

---

## 1. Patches Bordados — o produto-âncora

O patch é o coração do Patcho: barato de produzir, alta margem, e é literalmente o "selo de membro do parche". É o item onde investir primeiro em batch.

### Custo real (Brasil, pequena tiragem)

| Fornecedor | MOQ | ~R$/un | Obs |
|---|---|---|---|
| **Eagle Patches** | 10 | R$16 (10un) → R$11,75 (100un) → R$11,33 (250un) | Programação (digitalização) grátis. Emborrachados + bordados. SP. |
| **Toca dos Bordados** | 10 | a partir de R$18,04 (8×8cm) | Linha 100% poliéster, alto brilho. 1 arte/pedido. |
| **Artezanet** | ~50–100 | sob orçamento (ref. 100un) | Até 7 cores + fundo, até 18×18cm, corte a laser. |

**Faixa realista Patcho (patch 7–8cm, bordado, termocolante ou costura):**
- 50 un: ~R$ 13–16/un
- 100 un: ~R$ 9–12/un
- 250 un: ~R$ 8–11/un

**Custo de setup:** a "programação"/digitalização do bordado costuma ser grátis (Eagle) ou diluída no pedido. Esse é o pulo do gato: o molde do patch não tem custo recorrente.

### Variações premium (alinhadas com Loam Premium)
- **Patch de couro/courino gravado a laser** — visual rústico-premium, perfeito para a estética "terra". Fornecedores: Raposo Laser (gravação em couro), CRP Etiquetas (couro sintético, PVC, silicone, desde 2001), The Hat Store. Tipicamente R$ 8–25/un dependendo de tamanho e couro real vs sintético.
- **Patch woven (tecido/damask)** — leitura mais "etiqueta de marca fina" do que bordado encorpado. Bom para detalhe. Sai dos mesmos fornecedores de etiqueta tecida (Etiquetas Brasil, BestLabels).

### Acabamentos a especificar no orçamento
Corte a laser (qualquer formato), borda merrow (overlock clássica), termocolante (prensa/ferro) vs costura vs dupla-face. Para dirt-jump (suor, lavagem, sol), **termocolante + costura de reforço** ou patch costurado é o mais durável.

---

## 2. Stickers / Adesivos — o primeiro objeto físico

O caminho mais barato para um objeto Patcho no mundo. Funciona como "cartão de membro" gratuito/baixo custo que espalha a marca em quadros, garfos, capacetes, carros.

| Fornecedor | Mínimo | Material | Obs |
|---|---|---|---|
| **HGC Gráfica** | sob consulta | vinil fosco recortado | 5×5cm, impermeável, pré-recortado. Frete grátis > R$249,90. |
| **Gráfica Torino** | 50 un | vinil laminado | Qualquer formato, resistente a água/sol/frio. Arte grátis. |
| **A Panda** | sob consulta | vinil recorte eletrônico | À prova d'água, arte por R$20. |

**Faixa realista:** milheiro (1.000 un) de vinil 5×5cm costuma sair ~R$ 200–500 (R$ 0,20–0,50/un), caindo muito por escala. Para dirt-jump, **vinil laminado** (resistente a abrasão/sol) é obrigatório — não usar papel ou vinil sem laminação.

**Pagamento/frete:** Pix aceito na maioria; frete via Correios/Melhor Envio por CEP.

---

## 3. Bonés (dad-cap, aba curva) com bordado / patch de couro

Item de alto valor percebido e cara forte da marca. Bordado 3D ou patch de couro gravado a laser conversam diretamente com Loam Premium.

| Fornecedor | Local | MOQ | ~R$/un | Prazo |
|---|---|---|---|---|
| **Star Caps** | SC | 24 un | sob consulta | 30 dias úteis |
| **Agrafisil** | SP | 25 un | R$16,50–36,50 | sob consulta |
| **Box10 Bonés** | — | 10 un (kit) | sob consulta | 10 dias + frete |
| **Camisetas em 12h** | — | variável | ref. trucker DTF R$37 | rápido |

**Faixa realista Patcho (dad-cap bordado, lote 24–25):** R$ 22–40/un.
**Relevância regional:** Star Caps é de Santa Catarina — vantagem de frete e visita presencial vindo de Ibiraquera.

**Técnica:** bordado convencional (cores vibrantes) ou bordado 3D alto-relevo (Star Caps) para o ícone "lip". Patch de couro gravado a laser costurado é a opção mais premium/diferenciada. Evitar DTF/silk no boné para a marca premium — bordado/couro lê melhor.

---

## 4. Camiseta pesada (fio penteado / heavyweight oversized)

Aqui a vantagem regional é REAL — os melhores fornecedores de blank pesado estão a poucas horas de Ibiraquera (vale do Itajaí / Brusque).

### Blanks lisos para estampar (private label)

| Fornecedor | Local | Tecido / gramatura | MOQ / desconto |
|---|---|---|---|
| **Lunfe Malhas** ⭐ | Itajaí/SC | penteado 30/1 175g, **suedine pesada 300g**, estonada stone wash, oversized | desconto progressivo a partir de 20 pç, até 15 cores/modelo |
| **Monte Leste** | Brusque/SC | meia malha 30/1 penteado 100% algodão, oversized | fábrica própria |
| **Techmalhas** | — | 30.1 penteado, básica e oversized | grade P–XXGG |
| **Loja Mirante** | — | 30.1 penteado 160g (~200g/peça) | direto de fábrica |
| **IZ Têxtil** | — | básicas 100% algodão | atacado lojista |

**Faixa realista do BLANK (sem estampa):**
- Básica 160g penteado: ~R$ 18–28/un no atacado
- Oversized pesada 280–300g (suedine): ~R$ 35–55/un

**Relevância regional:** Lunfe (Itajaí) e Monte Leste (Brusque) ficam ~2h de Ibiraquera. Permite visita, amostra física, negociação direta e frete barato — alinhado ao "premium tangível". **Lunfe é a aposta nº1** para a camiseta pesada Patcho.

### Estampa
- **Terceirizar** silk/DTF/DTG numa estamparia local (Florianópolis tem várias) sobre o blank comprado — mais controle de qualidade premium.
- Para a marca premium, **serigrafia (silk) de boa pigmentação** ou DTG de alta resolução; evitar DTF barato que descasca.
- Não esquecer: **etiqueta tecida na gola** (ver §6) — é o que diferencia "camiseta com estampa" de "marca".

---

## 5. Moletom / Hoodie (careca ou capuz)

Maior capital imobilizado por peça → produzir por último, só depois das artes validadas.

| Fornecedor | Local | Tecido | MOQ | ~R$/un blank |
|---|---|---|---|---|
| **VB Camisetas (private label)** | — | 30/1 penteado, Pima, Tech Modal | 30 pç/modelo; degraus 30/60/120/240 | sob consulta |
| **Salazar Ocean** | — | careca 310g penteado, anti-torção | — | — |
| **moletom.com.br** | Franca/SP | pronta entrega | — | a partir de R$28 |
| **IZ Têxtil / Maré / Loading** | — | básicos | — | preço de fábrica |

**Faixa realista do BLANK careca pesado (310g, penteado):** ~R$ 50–90/un no atacado pequeno.
**Modelagem própria:** VB Camisetas aceita modelagem própria (AAMA/DXF/GGT/VET) a partir de **320 pç/modelo** — fora do alcance bootstrapped por enquanto; usar modelagem deles.

---

## 6. Etiqueta tecida de gola (woven neck label) — o detalhe premium

É barata e é o que transforma "camiseta estampada" em "marca". Obrigatório para Loam Premium.

| Fornecedor | MOQ | Tipo | Prazo amostra |
|---|---|---|---|
| **Artezanet** | 100 (ref. preço a 2.000) | bordada dobra-ao-meio (gola) | 15–20 dias úteis |
| **BestLabels** | 100/modelo | impressa cetim/nylon OU bordada digital | — |
| **Etiquetas Brasil** | consultar (41 anos) | tafetá, alta-definição, cetim, emborrachado | — |

**Faixa realista:** woven label de gola sai muito barata por escala — tipicamente **R$ 0,15–0,60/un** em pedidos de 500–2.000. MOQ 100 é acessível. Especificar: tafetá ou alta-definição, dobra-ao-meio (loop fold) para gola.

---

## 7. Batch vs Print-on-Demand (POD) — decisão bootstrapped

### POD nacional (validar sem estoque)

| Plataforma | Modelo | Custo camiseta | Branding | Obs |
|---|---|---|---|---|
| **Dimona / Dropsimples** | DTG, fábrica própria desde 1967 | catálogo já inclui 1 estampa; ex. peça ~R$30–50; **+R$18 estampa adicional** (costas) | etiqueta própria nas malhas Quality/Prime/Estonada | sem mensalidade, paga só na venda; emite NF mesmo só com CPF; integra Nuvemshop/Shopify/Loja Integrada |
| **Montink** | dropshipping nacional + filial EUA | similar | **branding total** (sem marca da plataforma no produto/etiqueta) | bom para vender BR e exterior |
| **Uma Penca** | POD ~20 anos | — | — | imprime+envia+atendimento |
| **Reserva INK** | marketplace de artistas | comissão por venda | baixo (vende dentro deles) | menos controle de marca/preço |
| **Printful/Gelato** | global | + frete/prazo internacional | total | só se público fora do BR |

**Margem POD (realidade):** camiseta a R$ 79,90 → no melhor caso (frete do cliente, CAC baixo) sobram R$ 15–25/venda (18–30% líq.); no pior (frete subsidiado, CAC alto) sobram R$ 3–8. POD é validação, não é o motor de margem premium.

### Quando POD vs Batch

```
Produto NOVO / arte não validada     → POD (Dimona/Montink). Risco zero de estoque.
Arte/modelo que JÁ vende             → Batch local SC. Margem premium + etiqueta + qualidade controlada.
Patches / bonés / stickers (o core)  → SEMPRE batch. Não há POD decente; são baratos e são a marca.
Moletom                              → POD primeiro (caro p/ estoque), batch só quando comprovado.
```

**Limite do POD para Patcho:** POD entrega DTG numa camiseta padrão — NÃO entrega o blank pesado 300g + etiqueta tecida + acabamento premium que a direção "Loam Premium" exige. Use POD para descobrir QUAIS artes vendem; produza o produto "de verdade" em batch local.

---

## 8. Infraestrutura BR (custos operacionais a lembrar)

- **Frete:** Correios + **Melhor Envio** (agrega transportadoras, etiqueta com desconto). Calcular por CEP/peso. Patch/sticker = carta/PAC barato; camiseta/moletom = PAC/Sedex.
- **Pagamento:** **Pix** é o padrão (taxa ~0% recebendo direto). Cartão via gateway da loja tem taxa.
- **Loja:** **Nuvemshop** (plano grátis inicial + planos a partir de ~R$ 50–100/mês; integra com Dimona/Montink e Melhor Envio nativamente).
- **Fiscal:** **MEI** (limite R$ 81k/ano) cobre o início bootstrapped; ao crescer, **Simples Nacional**. Dimona emite NF no custo mesmo com só CPF (ponte temporária).
- **Marca/INPI:** registrar "PATCHO" como marca no INPI (classe 25 vestuário + 26 patches/apliques) — ~R$ 142–355 de GRU por classe. Domínios via **registro.br** (patcho.com.br).

---

## 9. Plano de ataque sugerido (ordem + orçamento mínimo)

| Passo | Item | Qtd inicial | Investimento estimado |
|---|---|---|---|
| 1 | Stickers vinil laminado 5×5 | 1.000 | R$ 200–500 |
| 2 | Patch bordado 7–8cm (selo do parche) | 100 | R$ 900–1.200 |
| 3 | Etiqueta tecida de gola | 500 | R$ 150–300 |
| 4 | Boné dad-cap bordado/patch couro | 24–25 | R$ 550–1.000 |
| 5 | Camiseta pesada (blank Lunfe + silk local) | 30–50 | R$ 1.500–3.000 |
| 6 (depois) | Moletom careca 310g + estampa | 30 | R$ 2.500–4.000 |
| — | POD (Dimona) p/ validar artes extra | sob demanda | R$ 0 fixo |

**Capital mínimo para os 4 primeiros (objeto físico + selo + cara da marca):** ~R$ 1.800–3.000. Patches + stickers + etiqueta são o núcleo barato e alto-margem; bonés/camisetas escalam conforme a tribo cresce.

---

## Sources

- Eagle Patches — preços escalonados de patch bordado: https://www.eaglepatches.com.br/
- Toca dos Bordados — patch 8×8cm MOQ 10: https://www.tocadosbordados.com/
- Artezanet — patch bordado / etiqueta gola: https://www.artezanet.com.br/
- Lunfe Malhas (Itajaí/SC) — oversized 175g/300g suedine atacado: https://www.lunfemalhas.com.br/
- Monte Leste (Brusque/SC) — oversized 30/1 penteado: https://www.monteleste.com.br/camisetas-oversized
- Techmalhas / Loja Mirante / Rei das Camisetas — blanks penteado 160g: https://techmalhas.com.br/
- VB Camisetas — private label moletom MOQ 30: https://vbcamisetas.com.br/pages/private-label
- Salazar Ocean / moletom.com.br — moletom careca 310g: https://moletom.com.br/
- Star Caps (SC) / Agrafisil (SP) / Box10 — bonés bordados MOQ 24–25: https://starcaps.com.br/ , https://agrafisil.com.br/
- The Hat Store / Raposo Laser / CRP Etiquetas — patch de couro gravado a laser: https://thehatstore.com.br/custom-made , https://raposolaser.com.br/gravacao-a-laser/ , https://www.crpetiquetas.com.br/
- Etiquetas Brasil / BestLabels — etiqueta tecida de gola MOQ 100: https://www.etiquetasbrasil.com.br/ , https://www.bestlabels.com.br/
- HGC Gráfica / Gráfica Torino / A Panda — adesivos vinil 5×5cm: https://www.hgcgrafica.com.br/adesivo-em-vinil-5x5cm , https://graficatorino.com.br/adesivos-personalizados/
- Dimona / Dropsimples — POD DTG, custo + estampa adicional R$18: https://www.camisadimona.com.br/ , https://suporte.camisadimona.com.br/
- Montink / Uma Penca / Reserva INK — POD nacional, branding: https://ecommercenapratica.com/blog/plataformas-de-print-on-demand/
- PrintKK — panorama POD Brasil 2026: https://www.printkk.com/pt/blog/articles/print-on-demand-brazil
