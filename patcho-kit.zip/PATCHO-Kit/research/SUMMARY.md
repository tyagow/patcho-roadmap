---
doc: research-index
status: reference
updated: 2026-06-20
method: deep-research workflow — 7 parallel domain researchers + adversarial fact-check (BRL/fees/timelines), then synthesis
---

# Patcho — Pesquisa de Lançamento (índice)

Evidência por domínio que sustenta o [roadmap](../roadmap/roadmap.md). Cada arquivo
tem achados, custos em BRL, fornecedores reais e fontes. As figuras passaram por uma
camada de verificação adversarial (correções aplicadas no roadmap, p.ex. DAS MEI 2026
= R$82,05, INPI classe 25 com desconto MEI = R$440, patch bordado R$13–16/un @100).

| Domínio | Arquivo | Takeaway |
|---------|---------|----------|
| Manufatura & Sourcing | [manufacturing-sourcing.md](manufacturing-sourcing.md) | Edge regional SC: blanks heavyweight (Lunfe/Itajaí, Monte Leste/Brusque) e bonés (Star Caps) a ~2h. Patch bordado é o produto-âncora; POD só p/ validar arte. |
| E-commerce & Fulfillment | [ecommerce-fulfillment.md](ecommerce-fulfillment.md) | Nuvemshop Começo (R$0) + Pix herói (0,99%) + Melhor Envio. Fourthwall só p/ braço EN global. |
| Legal, Marca & Estrutura | [legal-ip.md](legal-ip.md) | MEI (CNAE 4781-4/00) ANTES do INPI (desconto 50%). Depositar marca classe 25 na semana 1 — o nome é o ativo. |
| Conteúdo & Social | [content-social.md](content-social.md) | Long-form "Backyard Build" → cortes via Opus Clip. His&Hers é o diferencial. 1k seguidores destrava Trial Reels. |
| Comunidade & Eventos | [community-events.md](community-events.md) | Dig days (quem anda, cava) → jams PRIVADOS/FREE com seguro AP. O "Selo do Ano" cunha legitimidade (playbook SOTY). |
| Preço & Unit Economics | [pricing-economics.md](pricing-economics.md) | Tee âncora R$129–139 (margem ~50–60%), patch margem 65–70%. Pré-venda DTF financia o estoque. |
| Concorrência & White Space | [competitive-landscape.md](competitive-landscape.md) | White space real: loam TROPICAL (verde-mata + barro), casal, comunidade aberta. Modelo Howies; evitar guerra de preço técnica. |

> Regenerar: rodar `.roadmap-pipeline.js` via Workflow atualiza estes arquivos e o roadmap.
