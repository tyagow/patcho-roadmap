# Patcho — E-commerce & Fulfillment Stack (Brasil-first, alcance global)

> Pesquisa interna · mid-2026 · todos os valores em **R$** (USD secundário)
> Contexto: marca bootstrapped de dirt-jump *lifestyle* (apparel + patches + conteúdo), base **Ibiraquera/Imbituba — SC**, modelo de **drops** guiado por conteúdo, voz bilíngue PT/EN.

---

## TL;DR — o stack recomendado

**Launch day (validar com drop pequeno):**
- **Plataforma:** Nuvemshop, **Plano Começo (grátis)** + **Nuvem Pago** (gateway nativo, sem tarifa de plataforma).
- **Pagamento:** Pix (0,99%) como herói + cartão à vista/parcelado + boleto. Pix vira o canal padrão por margem e zero chargeback.
- **Frete BR:** **Melhor Envio** integrado (PAC para padrão, SEDEX como upsell) — até ~80% mais barato que balcão.
- **Embalagem:** saco/envelope de segurança kraft + selo Patcho. ~R$ 1,50–3,50/un.
- **Global:** **não** abrir frete internacional no dia 1. Usar **Fourthwall** (print-on-demand, merchant of record) como vitrine `.com` paralela para a audiência EN — zero estoque, zero dor de alfândega para a Patcho.

**Once demand proves out:**
- Subir para **Nuvemshop Essencial/Impulso** quando taxas de cartão e apps justificarem.
- Negociar **contrato comercial direto com Correios** a partir de ~50 envios/mês (descontos ~40%).
- Internacional ativo via **Correios Exporta Fácil** para fãs específicos + manter Fourthwall para volume EN.
- Reavaliar Shopify **só** se o conteúdo escalar a ponto de exigir tema/checkout premium e apps que a Nuvemshop não cobre — custo em USD pesa no bootstrap.

---

## 1. Plataformas de loja — comparativo

| Critério | **Nuvemshop** | **Loja Integrada** | **Shopify** | **Fourthwall** |
|---|---|---|---|---|
| Mensalidade entrada | **R$ 0** (Começo) | **R$ 0** (grátis, 50 produtos) | ~US$ 39/mês (~R$ 210) Basic | **R$ 0** (físico sempre grátis) |
| Pix nativo | Sim (Nuvem Pago 0,99%) | Sim (via Pagali / gateways) | Sim, mas via gateway 3º (sem Shopify Payments no BR) | Não (Stripe/PayPal, foco global) |
| Tarifa de plataforma por venda | **0%** com Nuvem Pago | **0%** (não cobra comissão) | **+0,2%–2%** se usar gateway externo | **0%** em físico; 5% em digital (0% no Pro) |
| Foco | E-commerce BR, líder de mercado | E-commerce BR, simples | Global, robusto, caro p/ BR | Creator-merch global, POD |
| Moeda/idioma | BRL + PT nativo | BRL + PT nativo | BRL + multi-moeda (Markets) | Multi-moeda automática |
| Melhor p/ Patcho | **Loja-mãe BR** | Alternativa econômica | Só se escalar muito | **Braço global EN** |

### Notas por plataforma

**Nuvemshop** — líder BR, melhor custo-benefício para o caso Patcho.
- Plano Começo: **grátis, produtos ilimitados**, mas só permite **Nuvem Pago + Nuvem Envio** (suficiente para validar um drop).
- Plano Escala: **R$ 449/mês**. Next (enterprise) só faz sentido acima de R$ 100k/mês de faturamento.
- Tarifa de plataforma **zero** com Nuvem Pago em todos os planos pagos comuns. Gateways externos: **0,7%–2%** adicionais.

**Loja Integrada** — boa alternativa econômica, mas menos polida.
- Não cobra comissão sobre vendas em nenhum plano. Plano pago a partir de **R$ 54/mês**; grátis limita a 50 produtos e 5 mil visitas/mês.
- Gateway nativo **Pagali** com tarifa zero de plataforma; integra Mercado Pago, PagBank, Pagar.me, PayPal etc.
- Veredito Patcho: viável, mas a Nuvemshop entrega tema/checkout mais premium — alinhado ao posicionamento "Loam Premium".

**Shopify** — poderoso, porém caro e desalinhado ao bootstrap BR.
- **Shopify Payments não opera no Brasil**: obriga gateway terceiro (Mercado Pago, Pagar.me) com **+0,2%–2%** de surcharge da Shopify, além da taxa do gateway (cartão ~2,5%–3,5%).
- Base US$ 39/mês (US$ 29 no anual). Em BRL isso é custo fixo em dólar — risco cambial num bootstrap.
- Indicado **apenas** se o conteúdo escalar a ponto de exigir customização/apps que a Nuvemshop não atende.

**Fourthwall** — braço global ideal para a tese "filmar uma história que vende patches".
- **Sem mensalidade** para produtos físicos; só taxa de processamento (Stripe **2,9% + US$ 0,30** doméstico, **3,9% + US$ 0,30** internacional).
- **Print-on-demand + Merchant of Record**: a Patcho não toca estoque, frete nem imposto/VAT internacional. Fourthwall recolhe sales tax/VAT.
- Plano Pro opcional US$ 19/mês zera taxa de 5% em digital.
- Limitação: **não tem Pix** e o frete POD pode ser caro (abandono de carrinho). Por isso é **complemento global**, não loja-mãe BR.

---

## 2. Pagamentos — Pix, cartão, parcelamento

Realidade brasileira: **Pix domina** (80%+ dos adultos), é instantâneo e **sem chargeback**. Parcelamento é esperado acima de ~R$ 100.

### Nuvem Pago — taxas de referência (Plano Essencial, 2026)
| Forma | Taxa | Observação |
|---|---|---|
| **Pix** | **0,99%** | recebimento na hora — canal herói |
| Boleto | **R$ 2,39/boleto** | recebe em ~2 dias úteis |
| Cartão à vista — 30 dias | 4,49% (+R$ 0,35/transação) | prazo mais barato |
| Cartão à vista — 14 dias | 4,99% | |
| Cartão à vista — 2 dias | 5,49% | recebimento rápido, taxa maior |

**Parcelamento (juros que o lojista absorve, se optar por "sem juros" p/ cliente):**
2x: 3,18% · 3x: 4,77% · 6x: 9,54% · 12x: 19,08%.
> Recomendação Patcho: **repassar juros ao cliente** acima de 3x (parcelamento com juros), absorver só até 3x em peças premium. Em patches/itens baratos, focar Pix.

> ⚠️ Nuvem Pago **não permite antecipação** de recebíveis — opera só com prazos programados (2/14/30 dias). Planejar fluxo de caixa considerando o ciclo de 30 dias no cartão.

### Estratégia de checkout
- **Pix em destaque** (talvez pequeno desconto 5% Pix para empurrar margem e caixa).
- Cartão com parcelamento até 6x para ticket de apparel premium.
- Boleto opcional (público sem cartão), mas baixa prioridade visual.

---

## 3. Frete nacional — Correios vs Melhor Envio

**Melhor Envio vence para PME** (integração grátis + descontos de até ~80% vs balcão).

| Critério | PAC | SEDEX |
|---|---|---|
| Prazo | até 10 dias úteis | 1–3 dias úteis |
| Preço | mais barato (ex.: ~R$ 11,15 / 400g balcão) | 50–100% mais caro que PAC |
| Desconto via Melhor Envio | até ~80% vs balcão | até ~80% vs balcão |
| Integração API c/ loja | grátis | grátis |

- Reajuste Correios de **5,49%** em vigor desde início de 2026.
- Melhor Envio: integra grátis com Nuvemshop/Loja Integrada, gera etiqueta, tem **Ponto Parceiro** (postagem centralizada) e rastreio. Clube **Melhor Nível** dá desconto progressivo.
- A partir de **~50 pacotes/mês**, avaliar **contrato comercial direto nos Correios** (descontos ~40%) em paralelo.
- **Nota SC:** Ibiraquera/Imbituba — confirmar agência/Ponto Parceiro mais próximo para postagem; região litorânea pode ter menos pontos que capital. (Open question.)

### Estratégia de frete Patcho
- **Patches/itens leves (< 400g):** PAC via Melhor Envio, frete embutido ou baixo — ideal para "membership barata na parche".
- **Apparel:** PAC padrão + SEDEX como upsell de urgência no checkout.
- Considerar **frete grátis acima de X** (ex.: R$ 199) para subir ticket médio.

---

## 4. Embalagem — custo e branding

A embalagem É marketing no modelo de tribo. Manter **premium mas barato**: kraft + selo/patch.

| Item | Faixa BRL (atacado) | Uso Patcho |
|---|---|---|
| Envelope de segurança kraft | ~R$ 0,50–2,00/un. | patches + apparel leve |
| Caixa de papelão pequena | ~R$ 2,00–3,60/un. (varejo) | apparel premium, drops especiais |
| Fita adesiva/gomada | ~R$ 4,99/rolo (45mm) | fechamento |
| Selo/sticker Patcho + thank-you card | ~R$ 0,30–1,00/un. | branding, "bem-vindo à parche" |

- Fornecedores atacado: **Casa do Papelão**, **Papel Mania (Brás-SP)**, **NZB**, **Unisuprí**. Comprar volume → desconto.
- Custo de embalagem por pedido realista: **~R$ 1,50–3,50** (envelope/caixa + fita + selo + card).
- Dica: envelope kraft acomoda apparel melhor que caixa → **reduz peso e frete**.

---

## 5. Internacional — a realidade da dor

Enviar do Brasil para fora é **caro e lento** via Correios:
- **Exporta Fácil** EMS 5kg → EUA: **~R$ 350** (5–7 dias úteis). Econômico: **~R$ 200** (até 20 dias).
- Exige nota fiscal + fatura comercial corretas; inconsistência trava na alfândega.
- Para ticket de apparel, o frete internacional pode superar o valor do produto — **mata conversão**.

**Conclusão:** não montar operação de export própria no lançamento.
- **Fans EN avulsos:** atender sob demanda via Exporta Fácil (preço alto, transparente no checkout).
- **Volume global:** usar **Fourthwall** (POD + merchant of record) — imprime e envia local no destino, sem dor alfandegária para a Patcho. Trade-off: menos controle de qualidade/material da peça e margem menor.

---

## 6. Roteiro recomendado

**(a) Launch day — bootstrap, validar drop**
1. Nuvemshop **Começo (grátis)** + Nuvem Pago (Pix 0,99%, cartão, boleto).
2. Melhor Envio integrado (PAC + SEDEX upsell).
3. Embalagem kraft + selo (~R$ 1,50–3,50/pedido).
4. Fourthwall `.com` paralelo para audiência EN (POD, zero estoque).
5. Domínios: `patchoco.com` + `patcho.com.br` (registro.br p/ `.br`).

**(b) Once demand proves out**
1. Subir Nuvemshop → **Essencial/Impulso** se apps/temas justificarem.
2. Contrato direto Correios a partir de ~50 envios/mês.
3. Internacional ativo: Exporta Fácil para fãs + Fourthwall para volume.
4. Reavaliar Shopify só se escala de conteúdo exigir.

### Custos fixos mensais — cenário de lançamento
- Plataforma: **R$ 0** (Nuvemshop Começo)
- Domínio `.com.br`: **~R$ 40/ano** (registro.br) ≈ R$ 3,30/mês
- Domínio `.com`: **~US$ 12/ano** (~R$ 65)
- Fourthwall: **R$ 0** (físico)
- **Custo fixo recorrente ≈ R$ 0–10/mês** — tudo o resto é variável por venda (taxas + frete + embalagem).

---

## Sources
- Nuvemshop planos e taxas (litextension, nuvemshop.com.br/planos-e-precos, atendimento.nuvemshop.com.br)
- Nuvem Pago taxas cartão/parcelamento/prazos (atendimento.nuvemshop.com.br, litextension)
- Loja Integrada planos/taxas (litextension, lojaintegrada.com.br/planos, ajuda.lojaintegrada.com.br)
- Shopify Brazil pricing/Pix (easyappsecom, commerce-ui.com, cartdna.com)
- Fourthwall fees/shipping (help.fourthwall.com, fourthwall.com, perkupapp.com, bootstrappingecommerce.com)
- Melhor Envio vs Correios PAC/SEDEX (melhorenvio.com.br/blog, olist.com, calculohub.com.br)
- Internacional/Exporta Fácil/impostos (correios.com.br, nomadglobal.com, calculadorabrasil.com.br)
- Embalagem (blog.bling.com.br, casadopapelao.com.br, papelmaniaembalagens.com.br)

*Confiança geral: média-alta para taxas BR (fontes 2026 consistentes); média para frete internacional (preços variam por destino/peso); pendências marcadas como open questions.*
