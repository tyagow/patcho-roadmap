# Patcho — Backyard Dirt-Jump Brand

You are working on **Patcho**, a bootstrapped dirt-jump bike lifestyle brand by
**Tiago & Jaluza**, based in **Ibiraquera / Imbituba, Santa Catarina, Brazil**.
Direction: **Loam Premium**. Tagline: _Born in the yard. Built on dirt._

## How this folder is organized (content vs. presentation)

The rule: **markdown is the source of truth; HTML is generated from it.** To change
the brand or the plan, edit the markdown — then regenerate the HTML.

```
patcho-brand/
├── CLAUDE.md            ← you are here (AI entry point + map)
├── README.md           ← human entry point
├── project.yaml         ← Mission Control feed (keep next_action + status fresh)
├── brand/               ← CANONICAL brand content (edit these)
│   ├── 01-brand.md        story, name, positioning, launch thesis
│   ├── 02-identity.md     logo system, color, typography rules
│   └── 03-voice.md        voice & phrases
├── research/            ← deep-research outputs, one .md per domain + SUMMARY.md
├── roadmap/
│   ├── roadmap.md         ← CANONICAL launch roadmap (edit this)
│   └── patcho-roadmap.html  presentation (generated from roadmap.md)
├── brand-kit/           ← visual brand deliverables (HTML guides + editors)
├── export/              ← vector assets (SVG/PDF/PNG, 8 logo versions)
├── dist/                ← shareable bundles (zips, packaged kit)
└── memory/              ← session logs
```

## Working rules

1. **Edit markdown, regenerate HTML.** Never hand-edit a generated HTML as the
   primary change — update the `.md` source first, then rebuild the HTML to match.
2. **Keep the Loam aesthetic** in any HTML: palette in `brand/02-identity.md`,
   fonts Anton / Barlow Condensed / Archivo / Zilla Slab, dark terra background,
   argila accent, film-grain texture.
3. **Voice matters.** Any copy must pass `brand/03-voice.md` (the ✓/✕ lists).
4. **Location is core.** Ibiraquera/Imbituba SC — use it in story and logistics
   (local SC printing, the backyard trail, regional jams). Not São Paulo.
5. After a work session, update `project.yaml` `next_action` + `status`.

## Quick index

- New here? Read `brand/01-brand.md` then `roadmap/roadmap.md`.
- Building/launching? `roadmap/roadmap.md` is the plan; `research/` is the evidence.
- Need a visual? `brand-kit/patcho-loam-ptbr.html` (full guide),
  `roadmap/patcho-roadmap.html` (the roadmap presentation).
