# Patcho — Backyard Dirt-Jump Brand

**Born in the yard. Built on dirt.** · Tiago & Jaluza · Ibiraquera / Imbituba, SC ·
direction **Loam Premium** · `@patcho.co`

## What's where

| Folder | What it holds | Edit? |
|--------|---------------|-------|
| `brand/` | **Canonical brand content** — story, identity, voice (markdown = source of truth) | ✅ edit here |
| `roadmap/` | **Launch roadmap** — `roadmap.md` (source) + `patcho-roadmap.html` (presentation) | ✅ edit `.md` |
| `research/` | Deep-research outputs, one `.md` per domain + `SUMMARY.md` | reference |
| `brand-kit/` | Visual deliverables — HTML brand guide + logo/lip/selo editors | open in browser |
| `export/` | Vector logo assets (SVG / PDF / PNG, 8 versions) | hand to designers |
| `dist/` | Shareable bundles (zips, packaged kit) | distribution |
| `memory/` | Session logs | — |

## Start here

1. **The brand** → `brand/01-brand.md`
2. **The plan** → `roadmap/roadmap.md` (or open `roadmap/patcho-roadmap.html`)
3. **The evidence** → `research/SUMMARY.md`
4. **The visuals** → `brand-kit/patcho-loam-ptbr.html`

## The rule

Markdown is the source of truth; HTML is generated from it. Change the `.md`,
then regenerate the HTML. See `CLAUDE.md` for the AI working contract.
