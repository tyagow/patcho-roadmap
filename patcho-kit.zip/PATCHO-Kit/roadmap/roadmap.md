---
doc: launch-roadmap
status: canonical
updated: 2026-06-20
source: deep-research workflow (7 domain researchers + adversarial verification, 2026-06-20)
note: This is the editable source of truth. roadmap/patcho-roadmap.html is generated from it.
---

# PATCHO — Roadmap de Lançamento

> **Born in the yard. Built on dirt.** · Ibiraquera / Imbituba, SC · Tiago & Jaluza
> Direção **Loam Premium** · pesquisa profunda + verificação adversarial (jun/2026)

## A Tese

A Patcho não está abrindo uma marca de roupa — está filmando uma história que por acaso vende patches. O ativo que escala é conteúdo + tribo, não estoque. O patch barato (margem 65-70%) é o cartão de entrada no 'parche'; o apparel premium (tee R$129-139, margem ~50-60% no heavyweight 300g) vem depois, financiado por pré-venda. O white space é real e está vazio: loam TROPICAL (verde-mata + barro vermelho de SC), casal His&Hers como diferencial narrativo, backyard-build documentado, bilíngue PT/EN, comunidade ABERTA ('o parche acolhe quem cava') como antídoto ao localismo elitista do surf. Sequenciar: dar antes de vender, cavar antes de colher, filmar antes de fabricar.

## Posicionamento

Loam Premium tropical: streetwear earthy refinado que 'cheira a barro' — acima da Hardvision (tee R$109,90) e abaixo de Carnan/Piet (R$180-280), ancorado em R$129-139. Restraint = qualidade (gramatura 300g, etiqueta tecida de gola, bordado 3D, embalagem como ritual). NÃO punk-zine, NÃO mascote-cartoon, NÃO 'camiseta técnica respirável' (guerra de preço perdida contra ASW/Mauro Ribeiro). O modelo é Howies (casal-fundador + lugar + valores + tiragem pequena), a estética é loam tropical de Ibiraquera/Imbituba que nenhum concorrente global (frio/seco/americano/monolíngue) ou nacional (DIRT DAD = moto/agressivo) ocupa.

## As Fases

### Fase 0 · Fundação — Legal + Digital + Primeiro Objeto Físico
**Quando:** Semanas 1-3  
**Meta:** Existir legalmente, travar o nome em todo lugar, e ter o primeiro objeto físico distribuível (sticker) na mão — sem travar capital em estoque de apparel.

**Legal**
- Busca de anterioridade gratuita de PATCHO + variações fonéticas (PACHO, PATCHÔ, PATCH) no e-Marcas ANTES de pagar GRU
- Abrir MEI no Portal do Empreendedor com CNAE 4781-4/00 (comércio varejista de vestuário) — grátis, CNPJ na hora — ANTES de depositar a marca para garantir desconto INPI de 50%
- Solicitar Inscrição Estadual na SEF/SC para emitir NF-e de mercadoria
- Depositar marca PATCHO no INPI classe 25, nominativa + figurativa (R$880) se houver caixa; só mista (R$440) se apertar
- Confirmar com contador o CNAE secundário correto para evitar enquadramento como 'industrialização por encomenda' (1412-6/01, fora do MEI); modelo = produção terceirizada + revenda (comércio), NUNCA fabricação própria em escala

**Digital**
- Registrar patcho.com.br no registro.br por 5 anos (R$174, trava nome+preço)
- Registrar patchoco.com em provedor com WHOIS privacy grátis (Cloudflare a preço de custo) — checar preço de RENOVAÇÃO antes de fechar
- Montar Nuvemshop Plano Começo (R$0) + Nuvem Pago com Pix em destaque
- Integrar Melhor Envio desde o dia 1 — PAC para itens leves, SEDEX como upsell
- Confirmar agência Correios / Ponto Parceiro Melhor Envio mais próximo de Ibiraquera-Imbituba e frequência de coleta

**Produto**
- Encomendar 1.000 stickers de vinil LAMINADO 5x5cm (~R$200-500) — primeiro objeto físico, exigir laminado p/ resistir sol/abrasão
- Pedir cotação formal de 100 patches bordados 7-8cm (Eagle Patches / Toca dos Bordados) com a arte do ícone 'lip' — programação grátis
- Pedir amostra de etiqueta tecida de gola (Artezanet, MOQ 100, amostra 15-20 dias úteis) — confirmar jacquard-woven vs tafetá

**Entregáveis:** CNPJ MEI ativo + Inscrição Estadual; Marca PATCHO depositada no INPI (nº de processo = anterioridade desde o protocolo); patcho.com.br + patchoco.com registrados; Loja Nuvemshop no ar (modo rascunho) com Pix + Melhor Envio; 1.000 stickers laminados em mãos; Cotações formais de patch e etiqueta tecida

**Orçamento da fase:**
- MEI + INPI 2 formas + 2 domínios: R$ 1.090–1.470
- 1.000 stickers laminados: R$ 200–500
- DAS MEI (1 mês): R$ 82,05

**KPIs:** Marca depositada (1 nº de processo INPI); Loja publicável em <3 semanas; 1.000 stickers prontos para distribuir em qualquer trilha

**Riscos:** Squatting de marca se não depositar cedo — risco fatal pois o nome é o ativo central; Enquadramento errado de CNAE → desenquadramento + multa; Sticker não-laminado degrada ao sol/suor e parece amador

### Fase 1 · Ligar o Motor — Conteúdo + Semear a Cena
**Quando:** Semanas 4-12 (Meses 1-3)  
**Meta:** Construir o pipeline de conteúdo sustentável e aparecer onde a tribo já está, distribuindo stickers e patches. Meta-chave: cruzar 1.000 seguidores no IG para destravar Trial Reels.

**Conteúdo**
- Estruturar pipeline: gravar pesado em sessões batch → 'The Backyard Build' (long-form quinzenal âncora) → Opus Clip (cortes 9:16) → CapCut (refino/marca PT-EN)
- Escrever todo hook ANTES de gravar: abrir no send/whip/quase-acidente, texto 4-7 palavras na tela, NUNCA logo ou 'fala galera'
- Lançar séries recorrentes: His & Hers (o casal É o diferencial), Foam to Dirt, Wipeout Wednesday, Sunset Session
- Bater 3-5 Reels/semana + 1 long-form quinzenal + 1-2 Stories/dia; teto ~5 posts/sem/plataforma p/ evitar burnout
- SEO de micro-nicho (#dirtjump #pumptrack #trilhasc) + legendas bilíngues PT/EN com keywords; JAMAIS comprar seguidores (shadowban 14 dias)

**Comunidade**
- Semear antes de colher: aparecer em sessões existentes (Floripa, Criciúma, 'pedreira' SC) distribuindo stickers/patches por meses
- Entrar nos canais-semente: grupos Facebook 'Dirt jump Bmx Brasil' + 'Dirt Jumpers', fixar trilha oficial no Trailforks/komoot
- Recrutar 3-5 riders respeitados do corredor Floripa–Sul SC como embaixadores fundadores (futuro júri do Selo)
- Abordar lojas locais como 'casa do parche': Nativus (Imbituba), Aro 3 e Ao Sul Natural (Garopaba) — oferecer conteúdo+presença, NÃO dinheiro

**Produto**
- Receber lote de 100 patches bordados + 100 etiquetas tecidas
- DAR patches (não vender) a quem cava/anda — token de membro ganho, não comprado
- Validar artes de tee via POD Dimona/Montink (risco zero de estoque) — descobrir qual arte engaja antes de travar capital

**Entregáveis:** Pipeline de conteúdo rodando (1 long-form + 3-5 Reels/sem); ≥1.000 seguidores no IG (destrava Trial Reels); 3-5 embaixadores fundadores recrutados; 1 loja local como 'casa do parche'; Lista de espera de pré-venda crescendo

**Orçamento da fase:**
- 100 patches bordados (âncora): R$ 1.300–1.600
- 100 etiquetas tecidas: R$ 60–150
- Stack conteúdo (Opus Starter, 3 meses): R$ 240–420
- DAS MEI (3 meses): R$ 246

**KPIs:** Cruzar 1.000 seguidores IG; Viewed-vs-Swiped ≥75% nos Reels; Watch time + share rate + save rate em alta (não follower count bruto); Núcleo de comentaristas recorrentes formado ('o parche'); ER de nicho >3% (vs média 0,48%)

**Riscos:** Burnout da dupla sem produção em lote disciplinada; Trial Reels travado até 1k — ler Insights na mão na fase 0; Expectativa de viral: crescimento honesto é 300-2.000 seguidores em 90 dias; Opus Clip favorece fala limpa — ação pura pode exigir mais corte manual; Polimento excessivo mata o nicho (autenticidade crua > produção de agência)

### Fase 2 · Achar o Formato — Dig Days + Pré-venda
**Quando:** Meses 3-5  
**Meta:** Transformar a audiência em comunidade física via dig days near-free, e validar disposição a pagar via pré-venda antes de qualquer tiragem cheia.

**Comunidade**
- Rodar dig days (~R$150-400, caçamba de saibro): a igreja onde o patch é GANHO — o conteúdo mais autêntico ('cheira a barro')
- Aplicar a regra não-escrita BR: quem anda, cava — usar o dig day para entregar os primeiros patches ganhos
- Confirmar acesso a terra privada adequada (espaço p/ jumps + acesso de veículo + estacionamento) para futuros jams
- Confirmar diretamente com prefeituras de Imbituba e Garopaba os thresholds de alvará (público vs privado, lotação, ingresso)

**Produto**
- Abrir pré-venda da camiseta com Pix antecipado — o cliente financia o estoque (capital de giro ~R$0)
- Agendar visita presencial a Lunfe Malhas (Itajaí) ou Monte Leste (Brusque) — ~2h de Ibiraquera — para amostra física do blank heavyweight e negociação direta
- Encomendar etiqueta tecida de gola desde a primeira camiseta — detalhe barato que transforma 'estampa' em 'marca'
- Definir grade enxuta (mais M/G, 1-2 artes) para evitar encalhe — maior risco de margem

**Conteúdo**
- Documentar os dig days como o coração do storytelling — His&Hers + tribo cavando
- Usar o conteúdo de dig day para abrir a lista de pré-venda (escassez + pertencimento)

**Entregáveis:** ≥2 dig days realizados e documentados; Pré-venda da 1ª tee fechada com sell-through validado; Amostra física do blank heavyweight SC aprovada; Thresholds de permit das prefeituras confirmados

**Orçamento da fase:**
- 2 dig days (caçambas): R$ 300–800
- Visita fornecedor SC (combustível/amostras): R$ 200–400
- DAS MEI (2 meses): R$ 164

**KPIs:** ≥30 inscritos na lista de pré-venda; Sell-through de pré-venda ≥60% (gatilho p/ liberar Drop 1 cheio); ≥20 pessoas em dig day; Disposição a pagar validada na faixa R$119-149

**Riscos:** SC sazonal: inverno chuvoso = trilha molhada → pivotar p/ conteúdo/dig day, não jam; Encalhe de grade = maior dreno de capital bootstrapped — DTF sob demanda mitiga; Sem terra privada adequada, a cadência de jam muda

### Fase 3 · 1º Drop + 1º Jam
**Quando:** Meses 5-7 (mirar verão seco SC, Dez-Abr p/ o jam)  
**Meta:** Lançar o Drop 1 lean para a tribo já aquecida e coroar com o primeiro backyard jam privado — patches ganhos viram patches comprados.

**Produto**
- Produzir Drop 1 lean: 50 patches + stickers + 40 tees heavyweight de 1-2 artes vencedoras (batch local SC nas que venderam na pré-venda)
- Precificar: tee R$129-139 (Pix), patch R$44, kit sticker R$24, boné R$99 — empurrar Pix com 5% de desconto vs absorver cartão
- Frete grátis acima de ~R$199 para subir ticket médio; repassar parcelamento acima de 3x
- Migrar arte de >50un de DTF para serigrafia (compensa a partir de 30-50un)

**Comunidade**
- Realizar o 1º backyard jam PRIVADO, FREE, em terra própria/emprestada, sem venda de ingresso — evita alvará/Bombeiros/RC
- Não-cortáveis mesmo em jam privado: seguro AP (R$507-900) + termo de responsabilidade assinado + capacete obrigatório (valor de marca) + socorrista designado + acesso de ambulância mapeado
- Distribuir patch numerado/edição de jam (relíquia) aos participantes — tier acima do patch padrão

**Conteúdo**
- Tratar o jam como o evento de marketing do trimestre — filmar como o long-form âncora
- Cobertura His&Hers do drop + jam para o feed e cortes verticais

**Legal**
- Monitorar receita mensal vs teto MEI (R$81k/ano; >R$97,2k = desenquadramento retroativo c/ multa)
- Confirmar emissão de NF nas vendas PJ e marketplaces

**Entregáveis:** Drop 1 no ar e vendendo; 1º jam privado realizado e documentado em vídeo; Patch de edição de jam distribuído; Break-even do Drop 1 atingido

**Orçamento da fase:**
- Drop 1 lean (50 patches + stickers + 40 tees + embalagem): R$ 3.500–4.500
- 1º jam (terra própria, AP incluso): R$ 1.500–4.500
- DAS MEI (2 meses): R$ 164

**KPIs:** Sell-through Drop 1 ≥65% (break-even); Ticket médio >R$130; ≥30 riders no 1º jam; >80% das vendas em Pix (liquidez imediata); Margem bruta realizada ≥50% no tee, ≥65% no patch

**Riscos:** Jam subseguro expõe Tiago & Jaluza civil e criminalmente — termo NÃO substitui AP; Marca vista como extraindo da cena → tribo rejeita (tensão 'poser'); Jam agendado na época errada morre na chuva; Cartão parcelado corrói margem se não houver incentivo forte a Pix

### Fase 4 · Depois do Lançamento — Escala + Selo do Ano
**Quando:** Meses 7-12+  
**Meta:** Compor crescimento, adicionar SKUs de maior capital só após validação, e cunhar legitimidade cultural com o prêmio anual — o ativo de longo prazo da Patcho.

**Produto**
- Adicionar boné bordado 3D (Star Caps SC, lead 30 dias úteis) e moletom heavyweight (R$269-329) APENAS após a tee validar demanda — moletom é o maior capital travado
- Drop 2 fundeado pelo lucro do Drop 1
- Continuar pré-venda/tiragem limitada (modelo The Loam Wolf — zera estoque parado)

**Comunidade**
- Lançar o Selo do Ano / Parche do Ano: prêmio anual julgado por JÚRI DE PARES (não pela marca) — o playbook exato do Thrasher SOTY
- Realizar sempre na mesma época (Mar-Abr, verão seco SC) e documentar a cerimônia como o vídeo de marketing do ano
- Entregar patch numerado raro + troféu artesanal loam (cerâmica/madeira, R$100-400) — raridade > custo

**Legal**
- Definir gatilho de migração para ME/Simples (Anexo I, 4% efetivo): ao se aproximar de ~R$70k/ano OU ao internalizar produção — contratar contador (R$150-400/mês)
- Depositar INPI fase 2: classe 26 (patches avulsos) se vendidos como SKU, classe 41 (conteúdo) se monetizar canal/IP

**Conteúdo**
- Escalar stack (Opus Pro ~R$155-185/mês, vidIQ Pro ~R$55) só quando o volume justificar
- Montar vitrine Fourthwall em patchoco.com para audiência EN (zero estoque, zero alfândega, merchant of record) — pedir amostra antes p/ checar padrão Loam Premium

**Entregáveis:** 1ª edição do Selo do Ano realizada e documentada; Boné + moletom no catálogo (pós-validação); Braço global EN via Fourthwall no ar; Plano de migração MEI→ME definido com contador

**Orçamento da fase:**
- Selo do Ano 1ª edição: R$ 3.000–6.000
- Boné lote 24 (Star Caps): R$ 1.000+
- Moletom lote 30 (após validação): R$ 2.500–4.000
- Contador ME (quando migrar): R$ 150–400/mês

**KPIs:** 1.000+ seguidores convertidos em compradores recorrentes; Selo do Ano com cobertura/buzz na cena BR; Receita anualizada vs teto MEI monitorada; Moletom com sell-through ≥60% sem encalhe de grade

**Riscos:** Selo perde poder se executado de forma inconsistente — valor está em repetir todo ano com o mesmo código; Moletom cedo demais descapitaliza o bootstrap; Desenquadramento retroativo do MEI se ultrapassar R$97,2k/ano; Câmbio pressiona COGS de blanks/insumos DTF importados — revisar preço a cada drop; Fourthwall reduz controle de material/margem da peça premium

## Os Primeiros 7 Dias

1. Dia 1: Busca de anterioridade gratuita de PATCHO + variações fonéticas (PACHO, PATCHÔ, PATCH) no e-Marcas — confirma que o nome está livre ANTES de gastar.
2. Dia 1: Abrir MEI no Portal do Empreendedor com CNAE 4781-4/00 (comércio de vestuário) — CNPJ na hora, e este CNPJ vira o requerente no INPI (garante desconto de 50%).
3. Dia 2: Registrar patcho.com.br no registro.br por 5 anos (R$174) e patchoco.com em provedor com WHOIS privacy grátis (Cloudflare) — checar preço de renovação.
4. Dia 3: Encomendar 1.000 stickers de vinil LAMINADO 5x5cm (~R$200-500) — primeiro objeto físico Patcho, exigir laminado. Cotar por CEP de Imbituba.
5. Dia 4: Pedir orçamento formal de 100 patches bordados 7-8cm (Eagle Patches/Toca dos Bordados) com a arte do ícone 'lip' + amostra de etiqueta tecida (Artezanet).
6. Dia 5: Solicitar Inscrição Estadual na SEF/SC e confirmar com contador o CNAE secundário correto para não cair em 'industrialização por encomenda'.
7. Dia 6: Montar Nuvemshop Plano Começo + Nuvem Pago (Pix em destaque) + integrar Melhor Envio; confirmar agência Correios/Ponto Parceiro mais próximo de Ibiraquera-Imbituba.
8. Dia 7: Depositar a marca no INPI classe 25 (nominativa + figurativa se houver caixa) — gera nº de processo = anterioridade desde o protocolo. Gravar o primeiro 'Backyard Build' p/ alimentar o pipeline de conteúdo.

## Escada de Produto

| Tier | Item | Preço (BRL) | Nota |
|------|------|-------------|------|
| Token de entrada | Sticker vinil laminado 5x5cm (solto = brinde) | Grátis (brinde em todo pedido) / R$24 o kit cartela 4-6un | COGS <R$1 solto. Mecânica de pertencimento ao 'parche'. Dado em qualquer trilha/evento — primeiro objeto físico Patcho. |
| Membership (âncora) | Patch bordado 7-8cm (ícone 'lip') | R$ 39–49 | COGS R$13-16/un @100. Margem 65-70%. O coração da marca. DAR cedo (ganho por cavar/andar), VENDER depois. Nunca POD — sempre batch. |
| Membership premium | Patch de couro/courino gravado a laser OU patch numerado de edição/jam | R$ 49–79 (numerado, edição limitada) | Visual rústico-premium Loam. Relíquia de jam/founders. COGS quote-only (min ~100un) — pedir orçamento com a arte 'lip'. |
| Produto core | Camiseta heavyweight 300g estampada (etiqueta tecida de gola) | R$ 129–139 | COGS R$47-71/un (corrigido). Margem ~50-60%. Posiciona acima da Hardvision (R$109,90). Pré-venda DTF primeiro, batch local SC nas vencedoras. |
| Acessório | Boné dad-cap bordado 3D (Star Caps SC) | R$ 89–119 | One-size, zero risco de grade. Lead até 30 dias úteis — planejar p/ drop. Custo lower-bound R$22-40 não confirmado. |
| Topo (2º momento) | Moletom hoodie heavyweight 320g | R$ 269–329 | COGS R$70-100/un. Margem 63-79%. Maior capital travado + risco de grade — SÓ após tee validar, idealmente no inverno. |
| Selo (anual) | Parche do Ano — patch numerado raro + troféu artesanal | Não-vendável (prêmio, júri de pares) | O ativo cultural de longo prazo. Raridade > custo. Cunha legitimidade como o Thrasher SOTY. Repetir TODO ano com o mesmo código. |

## Orçamento

- **Lean (Drop 1):** R$ 4.000–5.500 (Drop 1 lean: MEI + 1 classe INPI + 2 domínios ~R$550 / + 1.000 stickers laminados ~R$350 / + 100 patches bordados ~R$1.400 / + 100 etiquetas tecidas ~R$150 / + 40 tees heavyweight via batch ou pré-venda DTF ~R$1.600 / + embalagem premium DIY ~R$200 / + stack de conteúdo 1 mês ~R$100)
- **Confortável:** R$ 9.000–13.000 (tudo do lean + INPI nominativa+figurativa R$880 + Drop 2 fundeado + fotos pagas + boné Star Caps lote 24 ~R$1.000 + seguro AP de 1 jam ~R$700 + caçamba/dig days + verba criadores/tráfego ~R$1.000)

| Categoria | BRL | Nota |
|-----------|-----|------|
| Legal/setup dia 1 (MEI + 1 classe INPI nominativa + patcho.com.br 5 anos + patchoco.com) | R$ 510–590 + R$82,05/mês DAS | DAS MEI comércio 2026 corrigido para R$82,05/mês. INPI classe 25 com desconto MEI R$440/classe — abrir MEI ANTES de depositar. |
| INPI 2 formas (nominativa + figurativa, classe 25) | R$ 880 | Recomendado se houver caixa: protege nome (ativo nº1) + emblema. Se apertar, só uma mista R$440. Fase 2 (classes 26+41) só quando virarem ativos. |
| 1.000 stickers vinil laminado 5x5cm | R$ 200–500 | Estimativa de mercado NÃO confirmada por cotação (HGC/Torino/Romana cotam por CEP). Exigir laminado. openQuestion: preço fechado por milheiro. |
| 100 patches bordados 7-8cm (produto-âncora) | R$ 1.300–1.600 | Faixa CORRIGIDA conservadora: R$13-16/un @100. Programação grátis confirmada. NÃO usar floor R$8-11. Lead ~12 dias úteis. |
| 100 etiquetas tecidas de gola (woven label) | R$ 60–150 | MOQ 100/modelo (Artezanet). R$0,15-0,60/un UNVERIFIED (cotação típica @2500un). Amostra 15-20 dias úteis. Detalhe premium obrigatório. |
| 40 camisetas heavyweight (batch local SC OU pré-venda DTF) | R$ 1.600–2.800 | COGS heavyweight 300g CORRIGIDO p/ R$47-71/un. Estratégia: validar via POD, pré-venda DTF (capital de giro ~R$0), batch local Lunfe/Monte Leste só nas vencedoras. |
| Boné bordado 3D (Star Caps SC, lote 24) | R$ 1.000+ (estimado) | R$22-40/un é LOWER-BOUND não confirmado; premium pode subir. Lead até 30 dias úteis. Fase comfortable, não no Drop 1 lean. |
| Embalagem premium DIY por pedido | R$ 1,50–3,50/un | Kraft + fita + selo/thank-you card. Atacado (Casa do Papelão / Papel Mania-Brás). O selo é branding da 'parche'. |
| Stack de conteúdo (Opus Clip Starter + CapCut grátis) | R$ 80–140/mês | CapCut watermark removal CORRIGIDO ~R$55 (Standard); vidIQ Pro ~R$55 só ao escalar. Início roda no grátis + Opus Starter. |
| Seguro AP de evento (1 jam) + caçamba dig day | R$ 507–900 (AP) + R$ 150–400 (caçamba) | Caçamba region-dependent não confirmada p/ Imbituba (estimativa SP ~R$300). AP avulso 100% digital. Só na fase de 1º Jam. |
| Selo Patcho 1ª edição (prêmio anual) | R$ 3.000–6.000 | Jam-as-stage + patch numerado + troféu artesanal loam (R$100-400) + vídeo anual. Raridade > custo. Fase 4. |

> **Notas de orçamento:** Todos os valores em BRL, mid-2026, bootstrapped 2 pessoas. CORREÇÕES aplicadas (preferindo o conservador): DAS MEI comércio 2026 = R$82,05/mês (não R$76,90, reajuste salário mínimo R$1.621). Patch bordado 7-8cm = R$13-16/un @100 (NÃO o floor otimista R$8-11; Eagle publica R$16-20/un base). COGS tee heavyweight 300g = R$47-71/un (blank R$37-53 + DTF R$10-18) → margem real ~50-60% a R$129-139, NÃO 60-68%; para 60%+ usar blank 240-280g ou subir preço p/ R$129-169. INPI classe 25 com desconto MEI = R$440/classe (abrir MEI ANTES de depositar). Shopify desatualizado no dossiê: Basic real ~US$19-29/mês, mas NÃO recomendado (custo fixo em USD + surcharge no BR). UNVERIFIED/openQuestions a confirmar por cotação viva: preço por milheiro de sticker laminado (R$200-500 estimado), patch couro laser (R$8-25 quote-only, min ~100un), boné Star Caps (R$22-40 lower-bound, pode subir no premium), etiqueta tecida (R$0,15-0,60/un típico @2500un), caçamba de saibro em Imbituba (R$150-400 estimado de SP), e thresholds de permit das prefeituras de Imbituba/Garopaba. Nuvemshop Essencial corrigido p/ ~R$69 e Impulso R$164 (não R$50-150). CapCut watermark removal ~R$55 e vidIQ Pro ~R$55 (faixas antigas estavam baixas).

## Stack de Canais

| Canal | Escolha | Nota |
|-------|---------|------|
| Loja BR (mãe) | Nuvemshop Plano Começo (R$0/mês) + Nuvem Pago | Produtos ilimitados, 0% tarifa de plataforma, tema premium alinhado a Loam. Subir p/ Essencial (~R$69) ou Impulso (R$164) só em escala — Escala R$449 não cedo. |
| Pagamento herói | Pix via Nuvem Pago (0,99%, sem chargeback, recebimento na hora) | 80%+ dos adultos. Desconto 5% no Pix é superior a absorver cartão (4,69-5,69% +R$0,35 no plano Começo). Nuvem Pago NÃO antecipa recebíveis — contar com Pix p/ liquidez. |
| Frete nacional | Melhor Envio (PAC itens leves, SEDEX upsell) | Até ~80% mais barato que balcão. Patches/stickers via PAC Mini (~R$12-22 SE/Sul); tee heavyweight provavelmente PAC comum. Contrato direto Correios a partir de ~50 envios/mês. |
| Audiência conteúdo | Instagram (Reels) + YouTube (long-form âncora) + TikTok | IG p/ tribo + Trial Reels (1k+); YouTube 'The Backyard Build' é a fábrica de matéria-prima; TikTok como search engine. Bilíngue PT/EN. |
| Braço global EN | Fourthwall em patchoco.com (POD + merchant of record) | Zero estoque, zero alfândega, recolhe VAT/sales tax. Sem Pix, menos controle de material. NÃO abrir frete internacional próprio (Exporta Fácil pode superar valor do produto). |
| Canais-semente da cena | Grupos Facebook 'Dirt jump Bmx Brasil' + 'Dirt Jumpers', Trailforks/komoot, lojas locais (Nativus/Aro 3/Ao Sul) | Semear antes de colher: aparecer em sessões SC distribuindo stickers/patches por meses antes do evento próprio. |

## Sistema de Conteúdo

| Série | Formato | Cadência | Nota |
|-------|---------|----------|------|
| The Backyard Build | YouTube long-form (âncora) | Quinzenal | Gravado em sessões batch — vira 10-20 verticais via Opus Clip → CapCut. A fábrica de matéria-prima do pipeline. |
| His & Hers | Reels/Stories (o casal Tiago & Jaluza) | Semanal | O casal É o diferencial narrativo (fosso estilo Howies). Humaniza a marca, dispara ER de nicho 3-6% vs 0,48% média. Lançar cedo. |
| Foam to Dirt | Reels (progressão foam pit → terra) | Semanal | Jornada de aprendizado/segurança — conteúdo de processo que clusteriza no algoritmo. |
| Wipeout Wednesday | Reels (quedas/bastidores) | Semanal (quarta) | Autenticidade crua > produção de agência. Abre no quase-acidente (hook explosivo 0-3s). |
| Sunset Session | Reels/Stories (estética loam tropical) | Semanal | Verde-mata + barro vermelho de SC — o ativo visual que nenhum concorrente tem. Fotografar barro ÚMIDO, não poeira seca. |
| Dig Day Diaries | Reels + corte no long-form | A cada dig day | Onde o patch é ganho — o conteúdo mais autêntico ('cheira a barro') e a abertura natural da lista de pré-venda. |

## Checklist Legal

| Item | Detalhe | Custo (BRL) | Prazo |
|------|---------|-------------|-------|
| Busca de anterioridade no e-Marcas | PATCHO + variações fonéticas (PACHO, PATCHÔ, PATCH) ANTES de pagar qualquer GRU — evita colisão/recusa | R$ 0 | Semana 1 |
| Abrir MEI (CNAE 4781-4/00 comércio de vestuário) | Portal do Empreendedor, CNPJ na hora. ANTES de depositar marca p/ garantir desconto INPI de 50%. Modelo = produção terceirizada + revenda (NUNCA fabricação própria em escala) | R$ 0 (+ R$82,05/mês DAS 2026) | Semana 1 |
| Inscrição Estadual SEF/SC | Necessária para emitir NF-e de mercadoria nas vendas PJ/marketplaces | R$ 0 | Semana 1-2 |
| Depósito de marca INPI classe 25 | Nominativa (nome, ativo nº1) + figurativa (emblema lip), com desconto MEI. Se apertar, só mista. Protocolo = anterioridade imediata (símbolo MD; ® só na concessão) | R$ 440 (1 forma) / R$ 880 (2 formas) | Semana 2-3 |
| Registrar patcho.com.br | registro.br por 5 anos — trava nome+preço, WHOIS privacy grátis PF | R$ 174 / 5 anos | Semana 1 |
| Registrar patchoco.com | Provedor com WHOIS privacy grátis (Cloudflare a preço de custo). CHECAR preço de renovação antes de fechar (armadilha 1º ano barato) | R$ 30–110/ano | Semana 1 |
| Confirmar CNAE secundário com contador | Evitar enquadramento como 'industrialização por encomenda' (1412-6/01, fora do MEI) → desenquadramento + multa | R$ 0–200 (consulta) | Semana 2 |
| Seguro AP de evento (antes de qualquer jam) | AP avulso 100% digital (Essor/AIG/Previsul) + termo de responsabilidade assinado + capacete obrigatório + socorrista + acesso de ambulância. Termo NÃO substitui AP | R$ 507–900/jam | Antes do 1º jam (Fase 3) |
| INPI fase 2 (classes 26 + 41) | Classe 26 se patch vendido como SKU avulso; classe 41 se conteúdo monetizar. Só quando virarem ativos (caducidade após 5 anos sem uso) | R$ 880 (2 classes c/ desconto) | Fase 4 |
| Gatilho de migração MEI → ME/Simples | Ao se aproximar de ~R$70k/ano OU internalizar produção. Anexo I = 4% efetivo até R$180k. Monitorar teto MEI R$81k (>R$97,2k = retroativo c/ multa) | Contador R$150–400/mês + abertura R$200–800 | Fase 4 (quando o gatilho disparar) |

## Fornecedores

- **Patch bordado (âncora)** — Eagle Patches (MOQ 10, programação grátis), Toca dos Bordados, Artgraf, Linha Darte.  
  _R$13-16/un @100 (faixa corrigida conservadora, NÃO R$8-11). Lead ~12 dias úteis. Pedir orçamento formal com a arte 'lip'._
- **Patch couro/courino laser (premium)** — Raposo Laser, CRP (min ~100un), The Hat Store.  
  _R$8-25/un é estimativa quote-only não corroborada p/ lote pequeno. Pedir orçamento real com a arte._
- **Camiseta blank heavyweight (edge regional)** — Lunfe Malhas (Itajaí/SC) — #1 pick, 30/1 combed 175g + suedine 300g, Monte Leste (Brusque/SC) — fábrica própria.  
  _~2h de Ibiraquera — agendar VISITA presencial p/ amostra física + negociação. Desconto progressivo a partir de 20pç. Confirmar se fazem etiqueta de gola embutida._
- **Boné** — Star Caps (SC, MOQ 24, bordado 3D, lead 30 dias úteis), Agrafisil (SP, MOQ 25, R$16,50-36,50), Box10.  
  _Star Caps em SC = vantagem de frete+visita. Preço quote-only, lower-bound R$22-40 não confirmado._
- **Etiqueta tecida de gola** — Artezanet (MOQ 100/modelo, amostra 15-20 dias úteis), BestLabels, Etiquetas Brasil.  
  _Detalhe premium obrigatório. Confirmar jacquard-woven vs tafetá ao cotar. R$0,15-0,60/un unverified (cotação típica @2500un)._
- **Sticker vinil laminado** — HGC, Gráfica Romana (lead 4 dias), Gráfica Torino, Rei do Sticker (durabilidade 3 anos), A Panda.  
  _EXIGIR laminado p/ resistir sol/abrasão. ~R$200-500/milheiro estimado, cotar por CEP de Imbituba._
- **Estampa (validação)** — Dimona/Dropsimples (DTG, sem mensalidade, emite NF com CPF, integra Nuvemshop), Montink (full branding).  
  _POD SÓ para validar qual arte vende — não entrega o blank 300g + etiqueta + acabamento que Loam Premium exige. Migrar p/ batch local nas vencedoras._
- **Embalagem premium** — Casa do Papelão, Papel Mania-Brás.  
  _Comprar atacado. Kraft + fita + selo/thank-you card = branding da 'parche'. R$1,50-3,50/pedido._

## Stack de Ferramentas

| Necessidade | Escolha | Custo (BRL) | Nota |
|-------------|---------|-------------|------|
| Loja e-commerce BR | Nuvemshop Plano Começo | R$ 0/mês | 0% tarifa de plataforma, produtos ilimitados, integra Dimona/Montink + Melhor Envio nativamente. |
| Pagamento | Nuvem Pago (Pix herói 0,99%) | 0,99% Pix / 4,69-5,69%+R$0,35 cartão | Plano Começo trava em Nuvem Pago + Nuvem Envio. Não antecipa recebíveis. |
| Frete | Melhor Envio | ~R$12-22/envio leve SE-Sul | Integração grátis, até ~80% desconto vs balcão. |
| Geração de cortes de vídeo | Opus Clip Starter | R$ 80–95/mês | ReframeAnything 9:16, legendas 97%. Pro (R$155-185) só ao escalar volume. Favorece fala limpa. |
| Refino/branding de vídeo | CapCut (free → Standard se precisar) | R$ 0 (free) / ~R$55 (Standard) / ~R$105 (Pro 4K) | Free cobre o início. Faixa corrigida — R$45 era irreal p/ 2026. |
| SEO YouTube | vidIQ (free → Pro) | R$ 0 (free) / ~R$55/mês (Pro) | Free permanente serve no começo. Pro só ao escalar long-form. |
| Braço global EN | Fourthwall (POD físico) | 0% mensalidade / 2,9%+US$0,30 doméstico, 3,9%+US$0,30 intl | Merchant of record, recolhe VAT/tax. Pedir amostra p/ checar padrão Loam Premium. |

## Métricas

| Métrica | Alvo | Quando |
|---------|------|--------|
| Seguidores IG | 1.000 (destrava Trial Reels) | Mês 3 |
| Viewed-vs-Swiped (Reels) | ≥75% | Contínuo a partir do Mês 1 |
| Engagement rate de nicho | >3% (vs média 0,48%) | Mês 2-3 |
| Inscritos na lista de pré-venda | ≥30 | Mês 4-5 |
| Sell-through da pré-venda | ≥60% (gatilho p/ Drop 1 cheio) | Mês 5 |
| Sell-through do Drop 1 | ≥65% (break-even) | Mês 6-7 |
| % vendas em Pix | >80% (liquidez imediata) | Cada drop |
| Margem bruta realizada | ≥50% tee / ≥65% patch | Cada drop |
| Riders no 1º jam | ≥30 | Mês 6-7 |
| Receita anual vs teto MEI | <R$81k (gatilho migração ~R$70k) | Monitorar mensal |

## Riscos Críticos & Mitigação

- **Squatting de marca — terceiro registra PATCHO primeiro e força rebranding (risco fatal, o nome é o ativo central)**  
  → _Depositar INPI classe 25 na 1ª semana, logo após abrir o MEI. Busca de anterioridade antes; protocolo gera anterioridade imediata._
- **Enquadramento errado de CNAE → Receita interpreta como industrialização por encomenda (1412-6/01, fora do MEI) = desenquadramento + multa**  
  → _Operar SEMPRE como produção terceirizada + revenda (comércio 4781-4/00). Confirmar CNAE secundário com contador antes de faturar._
- **Travar capital em estoque cedo demais (moletom/grade cheia) descapitaliza o bootstrap antes de validar demanda**  
  → _Conteúdo+comunidade primeiro. Validar arte via POD → pré-venda DTF com Pix antecipado (cliente financia o estoque) → batch local só nas vencedoras. Moletom só na Fase 4._
- **Jam subseguro expõe Tiago & Jaluza civil e criminalmente; dirt jump tem risco real de lesão grave**  
  → _Manter jams PRIVADOS/FREE em terra própria. Não-cortáveis: AP (R$507-900) + termo assinado + capacete obrigatório + socorrista + acesso de ambulância. Termo NÃO substitui AP._
- **Localismo elitista (lição do surf) — tribo backyard-build escorrega p/ gatekeeping e envelhece mal**  
  → _Posicionar explicitamente comunidade ABERTA: 'o parche acolhe quem cava'. Júri de pares no Selo, riders fundadores honrados por respeito, não dinheiro. Dar antes de pedir._
- **Cair em 'camiseta técnica respirável' joga Patcho na guerra de preço contra ASW/Mauro Ribeiro**  
  → _Vender cultura, não tecido. Liderar com loam tropical (verde-mata + barro vermelho), casal His&Hers, restraint = qualidade. Fosso = refinamento earthy, não spec técnica._
- **Burnout da dupla (14-20 peças/semana) ou consistência irregular (punida pelo algoritmo 2026 mais que baixa frequência)**  
  → _Produção em LOTE disciplinada: 1 sessão de filmagem → semanas de conteúdo via Opus Clip→CapCut. Teto ~5 posts/sem/plataforma. Consistência > frequência._
- **Desenquadramento retroativo do MEI ao ultrapassar R$97,2k/ano (com multa + juros)**  
  → _Monitorar receita mensal. Gatilho de migração p/ ME/Simples (Anexo I, 4%) ao se aproximar de ~R$70k/ano — contratar contador antes de estourar o teto._
- **Câmbio pressiona COGS (blanks premium + insumos DTF têm componente importado) e margem do tee já é ~50-60% (não 60-68%)**  
  → _Revisar preço a cada drop. Considerar blank 240-280g (mais barato) para manter 60%+ OU subir tee p/ R$129-169. Empurrar Pix 5% desconto vs absorver cartão._
- **Selo do Ano perde poder se executado de forma inconsistente — uma edição única não tem força**  
  → _Repetir TODO ano na mesma época (Mar-Abr, verão seco SC) com o mesmo código e júri de pares. O valor está inteiramente na repetição ritual._

---
_Gerado a partir da pesquisa profunda. Fontes por domínio em [../research/](../research/)._