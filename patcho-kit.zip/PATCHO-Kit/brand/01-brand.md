---
doc: brand-core
status: canonical
updated: 2026-06-20
---

# PATCHO — Brand Core

> **Born in the yard. Built on dirt.**
> _Nascido no quintal. Feito na terra._

Esta é a **fonte da verdade** da marca. O HTML e os materiais de apresentação
são gerados a partir daqui. Para mudar a marca, mude este arquivo.

## One-liner

Uma etiqueta de roupa premium que cheira a terra — herança outdoor encontrando
a alma do dirt jump. Direção: **Loam Premium**.

## De onde vem

Nasceu no quintal, em **Ibiraquera / Imbituba — Santa Catarina**: um foam pit no
fundo de casa e uma trilha de dirt jump na mata atlântica, com resi. Uma crew, um
casal — **Tiago & Jaluza**. Não veio de marca grande nem de escritório; veio da
terra, da pá e do litoral catarinense.

> A vibe da casa: mata, lagoa e mar de Ibiraquera; trilha de terra no quintal;
> comunidade de quem anda e cava. Esse senso de lugar é o diferencial — não é
> um genérico "brand de bike", é um lugar real com uma crew real.

## O nome (a melhor parte da marca)

- **Patch** (inglês) — o emblema bordado que se prega em tudo; também um pedaço
  de terra (o quintal, a trilha) e remendar a lip depois da chuva.
- **Parche** (espanhol latino) — "a tua crew" e o ponto onde ela se junta. Um
  dirt jump é, literalmente, um pedaço de terra onde a galera se reúne.
- **-cho** — terminação carinhosa, da família de _gaúcho_, _muchacho_. Quente,
  latina, da terra. Sem conotação ruim em PT, EN ou ES.

**A sacada:** o logo pode literalmente ser um patch. Produto, identidade e cartão
de membro viram a mesma coisa — vendeu um patch, vendeu pertencimento. Quem tem o
patch da Patcho faz parte do parche. **Somos Patcho.**

## Posicionamento — por que Loam Premium

"Loam" é o solo escuro, fértil e perfeito de moldar — a terra que todo construtor
de jump sonha. Limpo, mas terroso: nada de punk-zine, nada de mascote cartunesco.
Restrição lida como qualidade.

- **Escala pro produto.** Vira catálogo de roupa de verdade (camiseta pesada,
  moletom, jaqueta) sem perder a raiz.
- **Envelhece bem.** Tons de solo e oliva não datam como neon ou grunge.
- **Ocupa o espaço vazio.** A linhagem do esporte é preto/vermelho/branco.
  Verde-mata + barro é uma faixa que ninguém domina — e é a sua, brasileira,
  tropical, catarinense.
- **Margem.** O teto de preço premium é o mais alto entre as direções exploradas.

## A tese de lançamento

Vocês não estão abrindo uma marca de roupa — estão **filmando uma história que
por acaso vende patches**. As três peças já existem: a trilha na mata, o foam pit
e um casal. **Construir a tribo primeiro; o produto vem atrás.** Os patches são
como as pessoas entram no parche.

## Identidade digital

| Item | Valor | Status |
|------|-------|--------|
| Handle | `@patcho.co` | livre no IG / TikTok / YouTube (confirmar) |
| Domínio global | `patchoco.com` | registrar (patcho.co e patcho.com são de terceiros) |
| Domínio BR | `patcho.com.br` | registrar |
| Marca INPI | classe vestuário (NCL 25) + outras | checar antes de divulgar |

## Crew & papéis

- **Tiago** — build/trilha, direção criativa, conteúdo, operação.
- **Jaluza** — co-fundadora; o ângulo "His & Hers" (o casal) é diferencial de conteúdo.

## Arquivos relacionados

- [02-identity.md](02-identity.md) — sistema de logo, cor, tipografia
- [03-voice.md](03-voice.md) — voz e frases
- `../brand-kit/patcho-loam-ptbr.html` — brand guide visual completo
- `../roadmap/roadmap.md` — roadmap de lançamento (fonte da verdade)
