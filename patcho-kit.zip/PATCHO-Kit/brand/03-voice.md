---
doc: voice
status: canonical
updated: 2026-06-20
---

# PATCHO — Voz & Frases

Soa como um amigo te passando a pá, não uma marca te passando um catálogo. Curta,
com terra debaixo da unha, calorosa onde o esporte costuma ser frio — porque nasceu
de uma casa e de um casal. Bilíngue, sem pedir licença.

## Frases-âncora

- **Born in the yard. Built on dirt.** _(não traduzir — fica em inglês de propósito)_
- Terra é casa. / Dirt is home.
- Quem anda, cava. / If you ride, you dig.
- Acha o teu patch.
- Empacota. Manda. Remenda.
- Pá na mão.
- Uma crew. Um patch.
- Somos Patcho.
- Bora pro parche.

## ✓ Soa assim

- Curta e direta. Substantivos duros: terra, lip, barro, patch, quintal.
- Ritmo de dois tempos — "Empacota. Manda."
- Humor no lugar de agressividade.
- Solta uma frase em inglês no meio do português, sem traduzir.
- Mostra o lado sem glamour: a lip que a chuva levou, a remendada.
- Convida pelo trabalho — acolhe, nunca fecha a porta.

## ✕ Nunca soa assim

- Ficha técnica ("camada de carbono 23% mais leve").
- Gritaria de marombeiro em caixa-alta.
- Frase de pôster motivacional ("REALIZE SEUS SONHOS").
- Verniz de agência, corporativo.
- Spam de ponto de exclamação.
- Elitismo que humilha (a armadilha do "localismo" do surf).
