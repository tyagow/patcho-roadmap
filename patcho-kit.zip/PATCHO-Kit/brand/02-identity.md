---
doc: identity-system
status: canonical
updated: 2026-06-20
---

# PATCHO — Sistema de Identidade

## Sistema de cor — Loam (6 cores)

| Cor | Hex | Papel |
|-----|-----|-------|
| Carvão | `#171109` | Base escura · texto |
| Terra Escura | `#3B2F25` | Fundo · tecido |
| Barro | `#7A6A52` | Secundária |
| **Argila ★** | `#B98B5E` | **Destaque** |
| Oliva | `#6B7150` | Apoio natural |
| Osso | `#ECE5D6` | Base clara · texto |

**Combinações testadas:** Argila/Terra (herança principal) · Terra/Osso (etiquetas,
premium) · Osso/Oliva (natural) · Osso/Carvão (máximo contraste, tela).

**Leitura:** Loam como base + um toque de **Mata** (`#1C2E20 #2E5A3A #7E9466`) pro
lado brasileiro/tropical é a combinação mais própria e menos batida.

## Sistema de logo

Não é uma marca só — é um kit. Tudo desenhado em **uma cor primeiro** e testado no
"teste do aperto de olhos". A marca final: emblema empilhado com a **lip** (curva do
dirt jump desenhada à mão) sobre o nome.

| Versão | Uso |
|--------|-----|
| Principal (empilhada) | costas de camiseta, vitrine |
| Ícone | boné bordado, peito esquerdo (6 cm) |
| Monograma | espaço mínimo, 32px, debossing |
| Selo / patch | o produto-identidade central |
| Wordmark | traseira de boné, texto reto |

### Regras que decidem se o logo sobrevive

- **Construa pro meio mais difícil primeiro** (bordado em boné): texto ≥ 5–6 mm,
  linha ≥ 1 mm, área máx. ~10 × 5,5 cm. Sem serifa fina — vira borrão. Sans bold.
- **Uma cor primeiro:** preto chapado → invertido → 1 cor terra. Cor é a última
  decisão, não a primeira.
- **Teste do adesivo:** reduz a 2,5 cm e desfoca. Se o detalhe some, remova detalhe
  — não comprima.
- ⚠️ Licença de fonte ≠ permissão de copiar logo. Nunca traçar logo de terceiros.

## Tipografia (todas livres p/ uso comercial)

| Função | Fonte | Nota |
|--------|-------|------|
| Logotipo / títulos | **Barlow Condensed 800** | espinha dorsal; funciona bordada e impressa |
| Impacto | **Anton** | manchetes, capas; aceita textura leve |
| Corpo / web | **Archivo** | legendas, site, embalagem |
| Detalhe / etiqueta | **Zilla Slab** | números de série, tags, selos |

## Assets vetoriais

`../export/` → SVG / PDF / PNG, 8 versões (stacked, stacked-black, stacked-white,
icon, icon-black, icon-white, horizontal, selo). Fonte Barlow Condensed embutida.
